"""Server-side telemetry helpers."""

from collections.abc import Generator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass

from opentelemetry import context as otel_context
from opentelemetry.context import Context
from opentelemetry.trace import (
    INVALID_SPAN,
    Span,
    SpanKind,
    Status,
    StatusCode,
    get_current_span,
)

from fastmcp.telemetry import (
    error_span_attributes,
    extract_trace_context,
    get_tracer,
    restore_dropped_attributes,
    telemetry_mode,
)

# Marker attribute set on the SERVER span opened at the FastMCP middleware seam
# (see `fastmcp.server.low_level.FastMCPServerMiddleware._seam_span`). The seam
# opens one span per inbound request so failures rejected *before* the
# high-level path (auth, not-found, middleware vetoes) are still traced. The
# attribute is set for observability; enrichment detection uses the ContextVar
# below (the API `Span` type does not expose readable attributes).
SEAM_SPAN_MARKER = "fastmcp.span.seam"


# Tracks the SERVER span opened at the current request's seam. When the
# high-level path reaches `server_span` and this span is still the active span,
# `server_span` enriches it with component attributes instead of opening a
# second span — restoring attribute parity on the single per-request span.
@dataclass
class _SeamSpan:
    span: Span
    error: Exception | None = None


_active_seam_span: ContextVar[_SeamSpan | None] = ContextVar(
    "fastmcp_active_seam_span", default=None
)

# Set once `server_span` has claimed the request's SERVER span. A mounted
# server, or a tool calling `ctx.fastmcp.call_tool`, reaches `server_span`
# again inside that request; it records an INTERNAL span instead, so trace
# consumers see one request no matter how deep the call goes.
_server_span_open: ContextVar[bool] = ContextVar(
    "fastmcp_server_span_open", default=False
)


def get_auth_span_attributes() -> dict[str, str]:
    """Get auth attributes for the current request, if authenticated."""
    from fastmcp.server.dependencies import get_access_token

    attrs: dict[str, str] = {}
    try:
        token = get_access_token()
        if token:
            user_id = token.subject or token.client_id
            if user_id:
                attrs["enduser.id"] = user_id
            if token.scopes:
                attrs["enduser.scope"] = " ".join(token.scopes)
    except RuntimeError:
        pass
    return attrs


def get_session_span_attributes() -> dict[str, str]:
    """Get session attributes for the current request."""
    from fastmcp.server.dependencies import get_context

    attrs: dict[str, str] = {}
    try:
        ctx = get_context()
        if ctx.request_context is not None and ctx.session_id is not None:
            attrs["mcp.session.id"] = ctx.session_id
    except RuntimeError:
        pass
    return attrs


def get_protocol_span_attributes() -> dict[str, str]:
    """Get the protocol attributes for the current request.

    Mirrors the `mcp.protocol.version` and `jsonrpc.request.id` attributes the
    SDK's own `OpenTelemetryMiddleware` sets — FastMCP drops that middleware to
    avoid a duplicate SERVER span, so this restores them on FastMCP's span.
    """
    from fastmcp.server.dependencies import fastmcp_request_ctx

    req_ctx = fastmcp_request_ctx.get()
    attrs: dict[str, str] = {}
    if req_ctx is None:
        return attrs
    if req_ctx.protocol_version:
        attrs["mcp.protocol.version"] = req_ctx.protocol_version
    if req_ctx.request_id is not None:
        attrs["jsonrpc.request.id"] = req_ctx.request_id
    return attrs


def _get_parent_trace_context() -> Context | None:
    """Get parent trace context from request meta for distributed tracing."""
    from fastmcp.server.dependencies import fastmcp_request_ctx

    req_ctx = fastmcp_request_ctx.get()
    if req_ctx is not None and req_ctx.meta:
        return extract_trace_context(req_ctx.meta)
    return None


@contextmanager
def _propagation_only_span() -> Generator[Span, None, None]:
    """Attach the incoming `_meta` trace context without creating a span.

    This is what separates `propagation_only` from `off`. Both create no
    FastMCP spans, but `off` is fully transparent while `propagation_only`
    still has to *parent* whatever the request goes on to do: without the
    attach here, the trace context carried in `_meta` would be extracted and
    then thrown away, and a span created inside a tool handler — by the user or
    by the outer instrumentation layer that owns the MCP hierarchy — would
    start a brand new trace instead of continuing the caller's.

    Yields `INVALID_SPAN`, which is non-recording, so callers' `is_recording()`
    guards skip attribute and error bookkeeping on it.
    """
    parent_context = _get_parent_trace_context()
    if parent_context is None:
        yield INVALID_SPAN
        return
    token = otel_context.attach(parent_context)
    try:
        yield INVALID_SPAN
    finally:
        otel_context.detach(token)


def _build_server_span_attrs(
    method: str,
    server_name: str,
    component_type: str,
    component_key: str,
    resource_uri: str | None,
    tool_name: str | None,
    prompt_name: str | None,
) -> dict[str, str]:
    attrs: dict[str, str] = {
        # MCP semantic conventions
        "mcp.method.name": method,
        # FastMCP-specific attributes
        "fastmcp.server.name": server_name,
        "fastmcp.component.type": component_type,
        "fastmcp.component.key": component_key,
        **get_protocol_span_attributes(),
        **get_auth_span_attributes(),
        **get_session_span_attributes(),
    }
    if resource_uri is not None:
        attrs["mcp.resource.uri"] = resource_uri
    if tool_name is not None:
        attrs["gen_ai.tool.name"] = tool_name
        attrs["gen_ai.operation.name"] = "execute_tool"
    if prompt_name is not None:
        attrs["gen_ai.prompt.name"] = prompt_name
    return attrs


def record_span_exception(span: Span, e: Exception) -> None:
    """Record an exception and error status on a span."""
    if span.is_recording():
        span.set_attributes(error_span_attributes(e))
        span.record_exception(e)
        span.set_status(Status(StatusCode.ERROR, str(e)))


@contextmanager
def seam_span(method: str, server_name: str) -> Generator[Span, None, None]:
    """Open the per-request SERVER span at the FastMCP middleware seam.

    The span is named after the method and carries the base MCP attributes
    (`mcp.method.name`, `fastmcp.server.name`, auth/session context) so
    seam-only methods (`logging/setLevel`, `tasks/*`, `ping`, `initialize`, ...)
    are fully attributed even though they never reach the high-level path. It is
    marked with `SEAM_SPAN_MARKER` so a later `server_span` call in the
    high-level path enriches this span with component attributes instead of
    opening a second one. Exceptions raised anywhere below the seam — including
    rejections *before* the high-level path (auth, not-found, middleware vetoes)
    that would otherwise produce no SERVER span at all — are recorded here.

    In `propagation_only` mode no span is opened at all — this is the one place
    that has to know the difference, because the seam is where the incoming
    `_meta` parent context is applied for the whole request.
    """
    if telemetry_mode() == "propagation_only":
        with _propagation_only_span() as span:
            yield span
        return

    attrs = {
        SEAM_SPAN_MARKER: True,
        "mcp.method.name": method,
        "fastmcp.server.name": server_name,
        **get_protocol_span_attributes(),
        **get_auth_span_attributes(),
        **get_session_span_attributes(),
    }
    tracer = get_tracer()
    with tracer.start_as_current_span(
        method,
        context=_get_parent_trace_context(),
        kind=SpanKind.SERVER,
        attributes=attrs,
        record_exception=False,
        set_status_on_exception=False,
    ) as span:
        # Restore: `attributes=attrs` above is what makes on_start hooks and
        # the sampler see these values at creation time (the whole point of
        # this helper). But OTel's Tracer.start_span builds the span from
        # `sampling_result.attributes`, not the `attributes` kwarg directly —
        # a custom Sampler whose SamplingResult.attributes defaults to None
        # silently drops everything we passed. This only fires when the span
        # ends up with no attributes at all, so any sampler that supplied
        # attributes of its own — forwarding ours, redacting or replacing
        # some, or substituting entirely its own — is left untouched, as is
        # an SDK attribute limit that evicted some.
        if span.is_recording():
            restore_dropped_attributes(span, attrs)
        seam = _SeamSpan(span)
        token = _active_seam_span.set(seam)
        # A seam is a new inbound request, even one an in-process proxy sends
        # from inside another server's tool call.
        open_token = _server_span_open.set(False)
        try:
            yield span
        except Exception as e:
            seam.error = e
            raise
        finally:
            if seam.error is not None:
                record_span_exception(span, seam.error)
            _server_span_open.reset(open_token)
            _active_seam_span.reset(token)


@contextmanager
def server_span(
    name: str,
    method: str,
    server_name: str,
    component_type: str,
    component_key: str,
    resource_uri: str | None = None,
    tool_name: str | None = None,
    prompt_name: str | None = None,
) -> Generator[Span, None, None]:
    """Emit or enrich a SERVER span with standard MCP attributes and auth context.

    When the current active span is the request's seam span (opened by
    `FastMCPServerMiddleware` and marked with `SEAM_SPAN_MARKER`), this sets the
    component attributes on that span and yields it *without* starting a second
    span — so failures rejected before this point and the successful high-level
    call share one richly-attributed SERVER span. Otherwise (non-seam contexts,
    e.g. in-process `mcp.call_tool()` calls that bypass the dispatcher) it opens a
    new SERVER span as before.

    A call nested inside that span, through a mounted server or a tool calling
    `ctx.fastmcp.call_tool`, gets an INTERNAL span under the current one, so a
    request has exactly one SERVER span.

    Automatically records any exception on the span and sets error status.

    In `propagation_only` mode no span is opened or enriched. The seam has
    normally already attached the incoming parent context for this request;
    doing it again here is a no-op, and covers the in-process callers that
    bypass the dispatcher and so never reach the seam at all.
    """
    if telemetry_mode() == "propagation_only":
        with _propagation_only_span() as span:
            yield span
        return

    attrs = _build_server_span_attrs(
        method,
        server_name,
        component_type,
        component_key,
        resource_uri,
        tool_name,
        prompt_name,
    )

    if _server_span_open.get():
        with get_tracer().start_as_current_span(
            name,
            kind=SpanKind.INTERNAL,
            attributes=attrs,
            record_exception=False,
            set_status_on_exception=False,
        ) as span:
            if span.is_recording():
                restore_dropped_attributes(span, attrs)
            try:
                yield span
            except Exception as e:
                record_span_exception(span, e)
                raise
        return

    seam = _active_seam_span.get()
    active = get_current_span()
    if (
        seam is not None
        and seam.span is active
        and seam.span.is_recording()
        and seam.span.get_span_context().is_valid
    ):
        # Enrich the already-active seam span rather than opening a second one.
        seam.span.update_name(name)
        seam.span.set_attributes(attrs)
        token = _server_span_open.set(True)
        try:
            yield seam.span
        except Exception as e:
            # The seam owns recording, including failures later converted to
            # isError results and exceptions rewrapped by protocol handlers.
            seam.error = e
            raise
        finally:
            _server_span_open.reset(token)
        return

    tracer = get_tracer()
    with tracer.start_as_current_span(
        name,
        context=_get_parent_trace_context(),
        kind=SpanKind.SERVER,
        attributes=attrs,
        record_exception=False,
        set_status_on_exception=False,
    ) as span:
        # Restore for the same reason as `seam_span`: OTel builds the span
        # from `sampling_result.attributes`, which a custom Sampler may not
        # forward even though it was handed `attributes=attrs` above. Only
        # fires when the span ends up with no attributes at all.
        if span.is_recording():
            restore_dropped_attributes(span, attrs)
        token = _server_span_open.set(True)
        try:
            yield span
        except Exception as e:
            record_span_exception(span, e)
            raise
        finally:
            _server_span_open.reset(token)


@contextmanager
def delegate_span(
    name: str,
    provider_type: str,
    component_key: str,
    method: str | None = None,
) -> Generator[Span, None, None]:
    """Create an INTERNAL span for provider delegation.

    Used by FastMCPProvider when delegating to mounted servers.
    Automatically records any exception on the span and sets error status.
    """
    attrs: dict[str, str] = {
        "fastmcp.provider.type": provider_type,
        "fastmcp.component.key": component_key,
    }
    if method is not None:
        attrs["mcp.method.name"] = method

    tracer = get_tracer()
    with tracer.start_as_current_span(
        f"delegate {name}",
        attributes=attrs,
        record_exception=False,
        set_status_on_exception=False,
    ) as span:
        # Restore for the same reason as `seam_span`: OTel builds the span
        # from `sampling_result.attributes`, which a custom Sampler may not
        # forward even though it was handed `attributes=attrs` above. Only
        # fires when the span ends up with no attributes at all.
        if span.is_recording():
            restore_dropped_attributes(span, attrs)
        try:
            yield span
        except Exception as e:
            record_span_exception(span, e)
            raise


__all__ = [
    "SEAM_SPAN_MARKER",
    "delegate_span",
    "get_auth_span_attributes",
    "get_protocol_span_attributes",
    "get_session_span_attributes",
    "record_span_exception",
    "seam_span",
    "server_span",
]
