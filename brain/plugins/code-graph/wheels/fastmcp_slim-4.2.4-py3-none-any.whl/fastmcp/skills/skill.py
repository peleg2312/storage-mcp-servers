"""Storage-neutral agent skills."""

from __future__ import annotations

import hashlib
import os
import shutil
import tempfile
import warnings
from collections.abc import Mapping
from pathlib import Path, PureWindowsPath
from types import MappingProxyType
from typing import Any, Self, TypeGuard, cast
from urllib.parse import quote

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    GetCoreSchemaHandler,
    JsonValue,
    model_validator,
)
from pydantic_core import CoreSchema, core_schema

from fastmcp._warnings import FastMCPDeprecationWarning
from fastmcp.skills._constants import MAX_SKILL_BYTES, MAX_SKILL_FILES
from fastmcp.skills.models import (
    _SHA256_PATTERN,
    MCPSkill,
    SkillFrontmatter,
    SkillResource,
)


def _warn_wire_model(call: str) -> None:
    warnings.warn(
        f"`{call}` builds the 4.1 wire model, which is now `MCPSkill`; "
        "`fastmcp.skills.Skill` is the skill authoring class. Replace it with "
        f"`{call.replace('Skill', 'MCPSkill', 1)}` and "
        "`from fastmcp.skills import MCPSkill`. This alias is removed in FastMCP 4.3.",
        FastMCPDeprecationWarning,
        stacklevel=3,
    )


def _validate_limits(file_count: int, total_bytes: int) -> None:
    if file_count > MAX_SKILL_FILES:
        raise ValueError(f"A skill may contain at most {MAX_SKILL_FILES} files")
    if total_bytes > MAX_SKILL_BYTES:
        raise ValueError(f"A skill may contain at most {MAX_SKILL_BYTES} bytes")


def _validate_relative_path(path: str) -> str:
    if not isinstance(path, str) or not path:
        raise ValueError("Skill file paths must be non-empty strings")
    if (
        path.startswith("/")
        or PureWindowsPath(path).drive
        or "\\" in path
        or "\x00" in path
    ):
        raise ValueError(f"Skill file path must be relative POSIX: {path!r}")
    parts = path.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise ValueError(f"Skill file path contains an invalid segment: {path!r}")
    return path


def _validate_files(sizes: Mapping[str, int]) -> None:
    for path in sizes:
        _validate_relative_path(path)
    if "SKILL.md" not in sizes:
        raise ValueError("A skill must contain SKILL.md")
    _validate_limits(len(sizes), sum(sizes.values()))
    for path in sizes:
        parts = path.split("/")
        for index in range(1, len(parts)):
            if "/".join(parts[:index]) in sizes:
                raise ValueError(f"Skill file is also used as a directory: {path!r}")


class SkillFile(BaseModel):
    """One file of a skill, described by its digest and size instead of its bytes."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    digest: str = Field(pattern=_SHA256_PATTERN)
    size: int = Field(ge=0)


class SkillManifest(BaseModel):
    """A skill's frontmatter and files, without the files' contents.

    A provider can advertise a skill from its manifest and read a file only when
    a client reads it. See `SkillManifestProvider`.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    frontmatter: SkillFrontmatter
    files: dict[str, SkillFile]
    """Every file in the skill, keyed by relative path, including `SKILL.md`."""

    @model_validator(mode="after")
    def validate_files(self) -> Self:
        _validate_files({path: file.size for path, file in self.files.items()})
        return self

    def to_mcp_skill(self, path: str | None = None) -> MCPSkill:
        """Build the Skills extension entry for this skill served at `skill://{path}/`."""
        prefix = f"skill://{quote(path or self.frontmatter.name, safe='/')}/"
        resources = [
            SkillResource(
                uri=prefix + quote(file_path, safe="/"),
                digest=file.digest,
                size=file.size,
            )
            for file_path, file in self.files.items()
        ]
        return MCPSkill(
            uri=f"{prefix}SKILL.md",
            frontmatter=self.frontmatter.model_copy(deep=True),
            resources=resources,
        )


def _render_skill_md(frontmatter: Mapping[str, JsonValue], instructions: str) -> bytes:
    import yaml

    header = yaml.safe_dump(dict(frontmatter), sort_keys=False, allow_unicode=True)
    return f"---\n{header}---\n{instructions}".encode()


class _SkillMeta(type):
    def __instancecheck__(cls, instance: object) -> bool:
        # The public 4.1 spelling also identified wire entries. Do not extend
        # this compatibility behavior to subclasses of the authoring class.
        return super().__instancecheck__(instance) or (
            cls is Skill and isinstance(instance, MCPSkill)
        )


def _is_authored_skill(value: object) -> TypeGuard[Skill]:
    """Check real inheritance, excluding the public wire-model compatibility alias."""
    return issubclass(type(value), Skill)


class Skill(metaclass=_SkillMeta):
    """An agent skill: a `SKILL.md` plus supporting files, independent of storage.

    A `Skill` holds exact file bytes. It doesn't know where it came from or which
    URI it is served under; a provider decides that. Author one in Python with the
    keyword constructor, or snapshot one from a directory, package, or mapping of
    files.

    Example:
        ```python
        from fastmcp.skills import Skill

        skill = Skill(
            name="release-notes",
            description="Write release notes from merged pull requests.",
            instructions="# Release notes\\n\\nGroup changes by theme...",
            files={"template.md": "## Highlights\\n"},
        )
        ```
    """

    __slots__ = ("_files", "_manifest")

    _files: Mapping[str, bytes]
    _manifest: SkillManifest

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        # Existing authoring values stay intact; dictionaries and JSON retain
        # the 4.1 wire-model validation and serialization contract.
        if cls is not Skill:
            return core_schema.is_instance_schema(cls)
        wire_schema = handler.generate_schema(MCPSkill)
        return core_schema.union_schema(
            [core_schema.is_instance_schema(cls), wire_schema]
        )

    def __new__(cls, *args: Any, **kwargs: Any) -> Self:
        # In 4.1 `fastmcp.skills.Skill` was the wire model now named `MCPSkill`.
        # Its keywords (`uri`, `resources`) never mean an authored skill.
        if cls is Skill and ("uri" in kwargs or "resources" in kwargs):
            _warn_wire_model("Skill(uri=..., frontmatter=..., resources=...)")
            # Statically a `Skill`, so authoring code keeps its types.
            return cast(Any, MCPSkill(*args, **kwargs))
        return super().__new__(cls)

    @classmethod
    def model_validate(cls, obj: Any, **kwargs: Any) -> MCPSkill:
        """Deprecated 4.1 alias for `MCPSkill.model_validate`."""
        _warn_wire_model("Skill.model_validate(...)")
        return MCPSkill.model_validate(obj, **kwargs)

    @classmethod
    def model_validate_json(cls, json_data: str | bytes, **kwargs: Any) -> MCPSkill:
        """Deprecated 4.1 alias for `MCPSkill.model_validate_json`."""
        _warn_wire_model("Skill.model_validate_json(...)")
        return MCPSkill.model_validate_json(json_data, **kwargs)

    def __init__(
        self,
        *,
        name: str,
        description: str,
        instructions: str,
        files: Mapping[str, str | bytes] | None = None,
        frontmatter: Mapping[str, JsonValue] | None = None,
    ) -> None:
        extra = dict(frontmatter or {})
        for key in ("name", "description"):
            if key in extra:
                raise ValueError(f"Pass {key!r} as a Skill argument, not frontmatter")
        header = SkillFrontmatter.model_validate(
            {"name": name, "description": description, **extra}
        )
        contents: dict[str, str | bytes] = {
            "SKILL.md": _render_skill_md(header.root, instructions)
        }
        for path, content in (files or {}).items():
            if path == "SKILL.md":
                raise ValueError("Pass SKILL.md content as `instructions`")
            contents[path] = content
        self._initialize(contents)

    def _initialize(self, files: Mapping[str, str | bytes]) -> None:
        from fastmcp.skills._snapshot import parse_frontmatter

        normalized = {
            path: content.encode("utf-8")
            if isinstance(content, str)
            else bytes(content)
            for path, content in files.items()
        }
        _validate_files({path: len(content) for path, content in normalized.items()})
        contents = dict(sorted(normalized.items()))
        # Validated above, so the manifest skips validating the same files again.
        manifest = SkillManifest.model_construct(
            frontmatter=parse_frontmatter(contents["SKILL.md"]),
            files={
                path: SkillFile.model_construct(
                    digest=f"sha256:{hashlib.sha256(content).hexdigest()}",
                    size=len(content),
                )
                for path, content in contents.items()
            },
        )
        object.__setattr__(self, "_files", MappingProxyType(contents))
        object.__setattr__(self, "_manifest", manifest)

    def __setattr__(self, name: str, value: object) -> None:
        raise AttributeError("Skill is immutable")

    @classmethod
    def from_files(cls, files: Mapping[str, str | bytes]) -> Skill:
        """Create a skill from relative paths mapped to text or bytes.

        `files` must include `SKILL.md` with valid frontmatter.
        """
        skill = object.__new__(cls)
        skill._initialize(files)
        return skill

    @classmethod
    def from_directory(cls, path: str | os.PathLike[str]) -> Skill:
        """Read a skill folder once and return an immutable snapshot.

        The folder name must match the `name` in its `SKILL.md`. Symlinks and
        special files are rejected, so a snapshot never reaches outside the folder.
        """
        from fastmcp.skills._snapshot import scan_files

        root = Path(path).absolute()
        paths = scan_files(root)
        _validate_limits(len(paths), sum(file.stat().st_size for file in paths))
        files = {file.relative_to(root).as_posix(): file.read_bytes() for file in paths}
        skill = cls.from_files(files)
        if skill.name != root.name:
            raise ValueError(
                f"Skill folder {root.name!r} must match its SKILL.md name {skill.name!r}"
            )
        return skill

    @classmethod
    def from_package(cls, package: str, path: str) -> Skill:
        """Load a skill folder shipped as package data, such as `("my_pkg", "skills/review")`."""
        from importlib.resources import files as package_files

        clean = _validate_relative_path(path)
        root = package_files(package).joinpath(*clean.split("/"))
        if not root.is_dir():
            raise ValueError(f"Skill package path is not a directory: {package}:{path}")
        contents: dict[str, bytes] = {}

        def visit(directory: Any, prefix: str) -> None:
            for entry in directory.iterdir():
                relative = f"{prefix}{entry.name}"
                if entry.is_dir():
                    visit(entry, f"{relative}/")
                elif entry.is_file():
                    contents[relative] = entry.read_bytes()

        visit(root, "")
        skill = cls.from_files(contents)
        if skill.name != root.name:
            raise ValueError(
                f"Skill folder {root.name!r} must match its SKILL.md name {skill.name!r}"
            )
        return skill

    def to_directory(
        self, path: str | os.PathLike[str], *, overwrite: bool = False
    ) -> Path:
        """Write the skill's files into `path`, a folder named after the skill.

        The folder name must match the skill's `name`, so `from_directory` can
        read it back. An existing folder raises `FileExistsError` unless
        `overwrite` is set, in which case it is replaced: files that aren't
        part of the skill are removed. Files are staged before replacing an
        existing folder. If replacement and restoration both fail, the error
        identifies where the previous folder has been retained.
        """
        root = Path(path)
        if root.name != self.name:
            raise ValueError(
                f"Skill folder {root.name!r} must match the skill's name {self.name!r}"
            )
        if root.is_symlink():
            raise ValueError(f"Skill folder is a symlink: {root}")
        if root.exists():
            if not overwrite:
                raise FileExistsError(
                    f"Skill directory already exists: {root}. "
                    "Use overwrite=True to replace."
                )
            if not root.is_dir():
                raise ValueError(f"Skill folder is not a directory: {root}")
        root.parent.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=f".{root.name}-", dir=root.parent))
        previous = staging / "previous"
        try:
            replacement = staging / "new"
            for relative, content in self._files.items():
                target = replacement / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
            if root.exists():
                root.rename(previous)
            try:
                replacement.rename(root)
            except OSError:
                if previous.exists():
                    try:
                        previous.rename(root)
                    except OSError as exc:
                        raise OSError(
                            f"Could not restore {root}; previous skill remains at {previous}"
                        ) from exc
                raise
            if previous.exists():
                shutil.rmtree(previous)
        finally:
            if not previous.exists():
                shutil.rmtree(staging)
        return root

    @property
    def name(self) -> str:
        return self._manifest.frontmatter.name

    @property
    def description(self) -> str:
        return self._manifest.frontmatter.description

    @property
    def frontmatter(self) -> SkillFrontmatter:
        """A copy of the parsed frontmatter; changing it does not change the skill."""
        return self._manifest.frontmatter.model_copy(deep=True)

    @property
    def manifest(self) -> SkillManifest:
        """A copy of the skill's frontmatter and file digests; changing it does not change the skill."""
        return self._manifest.model_copy(deep=True)

    @property
    def files(self) -> Mapping[str, bytes]:
        """Every file in the skill, keyed by relative path, including `SKILL.md`."""
        return self._files

    def to_mcp_skill(self, path: str | None = None) -> MCPSkill:
        """Build the Skills extension entry for this skill served at `skill://{path}/`."""
        return self._manifest.to_mcp_skill(path)

    def __eq__(self, other: object) -> bool:
        return _is_authored_skill(other) and self._files == other._files

    def __hash__(self) -> int:
        return hash(tuple(self._files.items()))

    def __repr__(self) -> str:
        return f"Skill(name={self.name!r}, files={len(self._files)})"
