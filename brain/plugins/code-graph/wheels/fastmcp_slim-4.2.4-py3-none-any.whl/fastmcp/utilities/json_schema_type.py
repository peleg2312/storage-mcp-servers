"""Convert JSON Schema to Python types with validation.

The json_schema_to_type function converts a JSON Schema into a Python type that can be used
for validation with Pydantic. It supports:

- Basic types (string, number, integer, boolean, null)
- Complex types (arrays, objects)
- Format constraints (date-time, date, time, duration, uuid, email, uri)
- Numeric constraints (minimum, maximum, multipleOf)
- String constraints (minLength, maxLength, pattern)
- Array constraints (minItems, maxItems, uniqueItems)
- Object properties with defaults
- References and recursive schemas
- Enums and constants
- Union types

## Unsupported regex patterns

Pydantic uses a Rust-based regex engine that does not support all regex
features found in real-world JSON Schemas (particularly those from AWS,
Azure, and other large OpenAPI providers). Unsupported constructs include
lookahead/lookbehind assertions (`(?!...)`, `(?<=...)`), Unicode property
escapes (`\\p{Graph}`, `\\p{Print}`), and very large compiled patterns.

When a `pattern` constraint cannot be compiled, `json_schema_to_type`
degrades gracefully:

1. The pattern is **dropped** from the Pydantic `StringConstraints` so
   the type will not raise a `SchemaError`.
2. A `UserWarning` is emitted with the unsupported pattern.
3. The original pattern is preserved in the type metadata as
   `x-unsupported-pattern` (visible via `TypeAdapter(T).json_schema()`).
4. Other constraints (`minLength`, `maxLength`) are still enforced.

Example:
    ```python
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "minLength": 1},
            "age": {"type": "integer", "minimum": 0},
            "email": {"type": "string", "format": "email"}
        },
        "required": ["name", "age"]
    }

    # Name is optional and will be inferred from schema's "title" property if not provided
    Person = json_schema_to_type(schema)
    # Creates a validated dataclass with name, age, and optional email fields
    ```
"""

from __future__ import annotations

import hashlib
import json
import keyword
import math
import re
import sys
import threading
import warnings
from collections import OrderedDict
from collections.abc import Callable, Hashable, Mapping
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import MISSING, dataclass, field, fields, is_dataclass, make_dataclass
from datetime import date, datetime, time, timedelta
from functools import lru_cache
from types import MappingProxyType
from typing import (
    Annotated,
    Any,
    ForwardRef,
    Generic,
    Literal,
    NotRequired,
    TypeVar,
    Union,
    cast,
    get_args,
    get_type_hints,
    overload,
)
from urllib.parse import unquote
from uuid import UUID

from pydantic import (
    AnyUrl,
    BaseModel,
    BeforeValidator,
    ConfigDict,
    EmailStr,
    Field,
    GetCoreSchemaHandler,
    GetJsonSchemaHandler,
    GetPydanticSchema,
    Json,
    PlainValidator,
    StringConstraints,
    TypeAdapter,
    ValidationError,
    ValidatorFunctionWrapHandler,
    create_model,
    model_validator,
)
from pydantic.fields import FieldInfo
from pydantic_core import SchemaError as _PydanticSchemaError
from pydantic_core import core_schema
from typing_extensions import TypedDict

__all__ = ["JSONSchema", "json_schema_to_type"]


def _check_nesting(schema: Any) -> None:
    """Raise `ValueError` if dicts and lists in the schema nest too deeply.

    Normalizing and hashing a schema recurse once per level of nesting. This
    check measures the depth without recursing, so a schema that is too deep
    fails with the same error as one that exceeds the conversion depth limit.
    """
    stack: list[tuple[Any, int]] = [(schema, 1)]
    while stack:
        node, depth = stack.pop()
        if depth > _MAX_NESTING:
            raise ValueError("JSON schema is too deeply nested to convert")
        if isinstance(node, dict):
            stack.extend((child, depth + 1) for child in node.values())
        elif isinstance(node, list):
            stack.extend((child, depth + 1) for child in node)


def _normalize_yaml_types(obj: Any) -> Any:
    """Convert YAML-parsed types back to JSON-native types.

    ``yaml.safe_load`` converts ISO date-time strings to ``datetime``/``date``
    objects.  These crash ``json.dumps`` and produce wrong default values in
    dataclass fields.  This function recursively normalises them to strings.
    """
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, date):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {
            str(k) if not isinstance(k, str) else k: _normalize_yaml_types(v)
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_normalize_yaml_types(v) for v in obj]
    return obj


def _reject_all(v: Any) -> Any:
    """Validator that rejects every value, implementing JSON Schema `false`."""
    raise ValueError("No value is valid against a false schema")


# JSON Schema `false` means no value is valid. This type rejects everything
# during Pydantic validation.
_UnsatisfiableType = Annotated[Any, BeforeValidator(_reject_all)]

FORMAT_TYPES: dict[str, Any] = {
    "date-time": datetime,
    "date": date,
    "time": time,
    "duration": timedelta,
    "uuid": UUID,
    "email": EmailStr,
    "uri": AnyUrl,
    "json": Json,
}

_V = TypeVar("_V")


class _LRUCache(Generic[_V]):
    """Least recently used cache bounded by entry count and total weight.

    Each entry's weight is the serialized size of the whole schema the
    conversion started from. A generated class refers to the classes of its
    properties and keeps the schema it was built from, so it retains as much
    as the root schema describes. Charging that size keeps the total memory
    held by the cache within `max_weight`. An entry heavier than `max_weight`
    is not stored.
    """

    def __init__(self, max_entries: int, max_weight: int) -> None:
        self.max_entries = max_entries
        self.max_weight = max_weight
        self._items: OrderedDict[Hashable, tuple[_V, int]] = OrderedDict()
        self._weight = 0
        self._lock = threading.Lock()

    def get(self, key: Hashable) -> _V | None:
        with self._lock:
            item = self._items.get(key)
            if item is None:
                return None
            self._items.move_to_end(key)
            return item[0]

    def put(self, key: Hashable, value: _V, weight: int) -> None:
        with self._lock:
            previous = self._items.pop(key, None)
            if previous is not None:
                self._weight -= previous[1]
            if weight > self.max_weight:
                return
            self._items[key] = (value, weight)
            self._weight += weight
            while len(self._items) > self.max_entries or self._weight > self.max_weight:
                _, (_, evicted_weight) = self._items.popitem(last=False)
                self._weight -= evicted_weight

    def clear(self) -> None:
        with self._lock:
            self._items.clear()
            self._weight = 0

    def __len__(self) -> int:
        return len(self._items)


# Generated classes keyed by (schema hash + root schema hash, class name). Each
# class is weighted by the size of its root schema, so a conversion whose root
# is larger than the weight limit adds nothing to the cache.
_classes: _LRUCache[type] = _LRUCache(max_entries=5000, max_weight=4_000_000)
# TypeAdapters for whole schemas, keyed by schema hash. They hold their
# classes, so they are bounded the same way.
_adapters: _LRUCache[TypeAdapter[Any]] = _LRUCache(
    max_entries=1000, max_weight=4_000_000
)

# Limits on a single conversion. Depth counts nested schemas and `$ref` hops;
# steps count every schema visited.
_MAX_CONVERSION_DEPTH = 64
# Nesting of dicts and lists in the input. Each nested schema takes at most two
# levels (such as `properties` and then the property's schema).
_MAX_NESTING = 4 * _MAX_CONVERSION_DEPTH
_MAX_CONVERSION_STEPS = 50_000


@dataclass
class _Conversion:
    """State for one `json_schema_to_type` call."""

    root_hash: str
    root_size: int
    # Sanitized name of the class generated for the root schema; `"$ref": "#"`
    # resolves to that class. None when the root converts to something other
    # than a class (a union, a `$ref`, a dict), where "#" binds to the enclosing
    # class being built instead.
    root_class_name: str | None
    enclosing_class_name: str | None = None
    resolved_refs: dict[str, Any] = field(default_factory=dict)
    building: set[tuple[str, str]] = field(default_factory=set)
    classes: dict[tuple[str, str], type] = field(default_factory=dict)
    recursive_refs: dict[str, tuple[str, str]] = field(default_factory=dict)
    # Model and dataclass fields whose default failed its probe, possibly only
    # because a recursive reference was still unresolved; rechecked at the end.
    unchecked_defaults: list[tuple[type, str]] = field(default_factory=list)
    depth: int = 0
    steps: int = 0

    def reference(self, key: tuple[str, str]) -> ForwardRef:
        """Refer to a class's identity rather than its possibly shared display name."""
        digest = hashlib.sha256(repr(key).encode()).hexdigest()
        name = f"_FastMCPRef_{digest}"
        self.recursive_refs[name] = key
        return ForwardRef(name)


_conversion: ContextVar[_Conversion] = ContextVar("json_schema_conversion")


class JSONSchema(TypedDict):
    type: NotRequired[str | list[str]]
    properties: NotRequired[dict[str, JSONSchema]]
    required: NotRequired[list[str]]
    additionalProperties: NotRequired[bool | JSONSchema]
    items: NotRequired[JSONSchema | list[JSONSchema]]
    enum: NotRequired[list[Any]]
    const: NotRequired[Any]
    default: NotRequired[Any]
    description: NotRequired[str]
    title: NotRequired[str]
    examples: NotRequired[list[Any]]
    format: NotRequired[str]
    allOf: NotRequired[list[JSONSchema]]
    anyOf: NotRequired[list[JSONSchema]]
    oneOf: NotRequired[list[JSONSchema]]
    not_: NotRequired[JSONSchema]
    definitions: NotRequired[dict[str, JSONSchema]]
    dependencies: NotRequired[dict[str, JSONSchema | list[str]]]
    pattern: NotRequired[str]
    minLength: NotRequired[int]
    maxLength: NotRequired[int]
    minimum: NotRequired[int | float]
    maximum: NotRequired[int | float]
    exclusiveMinimum: NotRequired[int | float]
    exclusiveMaximum: NotRequired[int | float]
    multipleOf: NotRequired[int | float]
    uniqueItems: NotRequired[bool]
    minItems: NotRequired[int]
    maxItems: NotRequired[int]
    additionalItems: NotRequired[bool | JSONSchema]


def json_schema_to_type(
    schema: Mapping[str, Any] | bool,
    name: str | None = None,
) -> type:
    """Convert JSON schema to appropriate Python type with validation.

    Args:
        schema: A JSON Schema dictionary defining the type structure and validation rules.
            Boolean schemas are also accepted (``True`` = any type, ``False`` = unsatisfiable).
        name: Optional name for object schemas. Only allowed when schema type is "object".
            If not provided for objects, name will be inferred from schema's "title"
            property or default to "Root".

    Returns:
        A Python type (typically a dataclass for objects) with Pydantic validation

        Positional arrays validate each present ``prefixItems`` position and
        apply ``items`` only to the tail. Arrays pinned to the prefix length
        hydrate as tuples; other arrays remain lists. Unrestricted tails preserve
        prefix values for compatibility; constrained tails hydrate each position.

    Raises:
        ValueError: If a name is provided for a non-object schema, or if the
            schema is too deeply nested or too large to convert.

    Examples:
        Create a dataclass from an object schema:
        ```python
        schema = {
            "type": "object",
            "title": "Person",
            "properties": {
                "name": {"type": "string", "minLength": 1},
                "age": {"type": "integer", "minimum": 0},
                "email": {"type": "string", "format": "email"}
            },
            "required": ["name", "age"]
        }

        Person = json_schema_to_type(schema)
        # Creates a dataclass with name, age, and optional email fields:
        # @dataclass
        # class Person:
        #     name: str
        #     age: int
        #     email: str | None = None
        ```
        Person(name="John", age=30)

        Create a scalar type with constraints:
        ```python
        schema = {
            "type": "string",
            "minLength": 3,
            "pattern": "^[A-Z][a-z]+$"
        }

        NameType = json_schema_to_type(schema)
        # Creates Annotated[str, StringConstraints(min_length=3, pattern="^[A-Z][a-z]+$")]

        @dataclass
        class Name:
            name: NameType
        ```
    """
    # Boolean schemas (JSON Schema 2020-12 §4.3.2; also valid since draft-06)
    if schema is True:
        return Any
    if schema is False:
        return _UnsatisfiableType  # type: ignore[return-value]  # ty:ignore[invalid-return-type]

    _check_nesting(schema)

    # Normalise YAML-parsed types (datetime/date → str, non-str keys → str)
    # so that downstream json.dumps/hashing and default values work correctly.
    return _convert_normalized(_normalize_yaml_types(schema), name)


def _convert_normalized(schema: dict[str, Any], name: str | None) -> type:
    root_hash, root_size = _schema_digest(schema)
    conversion = _Conversion(
        root_hash=root_hash,
        root_size=root_size,
        root_class_name=_root_class_name(schema, name),
    )
    token = _conversion.set(conversion)
    try:
        # Always use the top-level schema for references
        if schema.get("type") == "object":
            result = _object_schema_to_type(schema, schemas=schema, name=name)
        elif name:
            raise ValueError(f"Can not apply name to non-object schema: {name}")
        else:
            result = _schema_to_type(schema, schemas=schema)
        _resolve_recursive_types(conversion)
        # Publish only complete graphs: another conversion must not reuse a
        # class whose recursive fields still depend on this conversion's namespace.
        for key, cls in conversion.classes.items():
            _classes.put(key, cls, conversion.root_size)
        return result  # type: ignore[return-value]  # ty:ignore[invalid-return-type]
    finally:
        _conversion.reset(token)


def _root_class_name(schema: Mapping[str, Any], name: str | None) -> str | None:
    """Name of the class the root schema converts to, or None if it has none.

    Only an object root with properties becomes a class (including the
    object member of a type list such as `["object", "null"]`).
    """
    schema_type = schema.get("type")
    is_object = schema_type == "object" or (
        isinstance(schema_type, list) and "object" in schema_type
    )
    if not is_object or not schema.get("properties"):
        return None
    return _sanitize_name(name or _schema_title(schema, "Root"))


def _resolve_recursive_types(conversion: _Conversion) -> None:
    """Bind recursive fields after every class in the conversion has been built."""
    if not conversion.recursive_refs and not conversion.unchecked_defaults:
        return
    namespace = {
        name: conversion.classes[key] for name, key in conversion.recursive_refs.items()
    }
    # Root references use the root's public name, including when a nested
    # mutually recursive class also points back to the conversion root.
    root_class_name = conversion.root_class_name
    if root_class_name is not None:
        for cls in conversion.classes.values():
            if cls.__name__ == root_class_name:
                namespace[root_class_name] = cls
    for cls in conversion.classes.values():
        if conversion.recursive_refs and is_dataclass(cls):
            hints = get_type_hints(
                cls,
                localns={cls.__name__: cls, **namespace},
                include_extras=True,
            )
            cls.__annotations__.update(hints)
            for dataclass_field in fields(cls):
                dataclass_field.type = hints[dataclass_field.name]
    for cls in conversion.classes.values():
        if conversion.recursive_refs and issubclass(cls, BaseModel):
            cls.model_rebuild(
                force=True, _types_namespace={cls.__name__: cls, **namespace}
            )
    rechecked: set[type[BaseModel]] = set()
    for cls, field_name in conversion.unchecked_defaults:
        if issubclass(cls, BaseModel):
            # safe_create_model stores a reserved property name under a
            # generated field name with the property name as its alias.
            field_name = next(
                name
                for name, info in cls.model_fields.items()
                if (info.alias or name) == field_name
            )
            field_info = cls.model_fields[field_name]
            # `annotation` alone drops constraints such as `minimum`
            annotation = field_info.rebuild_annotation()
            if _default_is_valid(annotation, field_info.default):
                field_info.validate_default = True
                rechecked.add(cls)
            continue
        dataclass_field = cls.__dataclass_fields__[field_name]  # type: ignore[attr-defined]  # ty:ignore[missing-attribute]
        factory = dataclass_field.default_factory
        default = factory() if callable(factory) else dataclass_field.default
        # A `"#"` reference in a nested dataclass stays a forward reference
        # to the root, so the probe needs the namespace.
        if _default_is_valid(dataclass_field.type, default, namespace):
            dataclass_field.metadata = MappingProxyType(
                {**dataclass_field.metadata, "validate_default": True}
            )
    for model in rechecked:
        model.model_rebuild(
            force=True, _types_namespace={model.__name__: model, **namespace}
        )


def _default_is_valid(
    field_type: Any, default: Any, namespace: dict[str, Any] | None = None
) -> bool:
    try:
        adapter = TypeAdapter(field_type)
        if namespace:
            adapter.rebuild(_types_namespace=namespace)
        adapter.validate_python(default)
    except Exception:
        # Invalid, or not checkable yet because a recursive reference is unresolved
        return False
    return True


def json_schema_to_type_adapter(schema: Mapping[str, Any] | bool) -> TypeAdapter[Any]:
    """Return a cached `TypeAdapter` for `json_schema_to_type(schema)`.

    Adapters are cached by schema content in a bounded cache, so the classes
    they hold are released when they are evicted.
    """
    if isinstance(schema, bool):
        return TypeAdapter(json_schema_to_type(schema))
    _check_nesting(schema)
    schema = _normalize_yaml_types(schema)
    key, size = _schema_digest(schema)
    adapter = _adapters.get(key)
    if adapter is None:
        adapter = TypeAdapter(_convert_normalized(schema, None))
        _adapters.put(key, adapter, size)
    return adapter


def _hash_schema(schema: Mapping[str, Any]) -> str:
    """Generate a deterministic hash for schema caching."""
    return _schema_digest(schema)[0]


def _schema_digest(schema: Mapping[str, Any] | bool) -> tuple[str, int]:
    """Return a deterministic hash of the schema and its serialized size.

    Handles non-JSON-native types (datetime, date, bool keys) that can
    appear in schemas loaded from YAML, which auto-parses date strings.
    Uses ``default=str`` for unserializable values and drops ``sort_keys``
    to avoid ``TypeError`` when dicts mix ``bool`` and ``str`` keys.
    """
    try:
        raw = json.dumps(schema, sort_keys=True, default=str)
    except TypeError:
        # Mixed key types (bool + str) can't be sorted; fall back
        raw = json.dumps(schema, default=str)
    encoded = raw.encode()
    return hashlib.sha256(encoded).hexdigest(), len(encoded)


def _resolve_ref(ref: str, schemas: Mapping[str, Any]) -> Mapping[str, Any]:
    """Resolve JSON Schema reference to target schema."""
    # Decode the URI fragment before splitting and unescaping JSON Pointer tokens.
    path = unquote(ref).removeprefix("#/").split("/")
    current = schemas
    for part in path:
        part = part.replace("~1", "/").replace("~0", "~")
        current = current.get(part, {})
    return current


def _count(value: Any, *, maximum: bool = False) -> Any:
    """Normalize a JSON Schema count such as minLength or maxItems for Pydantic.

    JSON allows writing a count as `2.0`. A count above `sys.maxsize` exceeds any
    real length: as a maximum it constrains nothing and is dropped, and as a
    minimum it is clamped to a value Pydantic accepts that still rejects
    everything.
    """
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    if isinstance(value, int) and not isinstance(value, bool) and value > sys.maxsize:
        return None if maximum else sys.maxsize + 1
    return value


def _create_string_type(schema: Mapping[str, Any]) -> type | Annotated[Any, ...]:
    """Create string type with optional constraints."""
    if "const" in schema:
        return Literal[schema["const"]]  # type: ignore

    fmt = schema.get("format")
    base: Any = FORMAT_TYPES.get(fmt, str) if fmt else str

    constraints = {
        k: v
        for k, v in {
            "min_length": _count(schema.get("minLength")),
            "max_length": _count(schema.get("maxLength"), maximum=True),
            "pattern": schema.get("pattern"),
        }.items()
        if v is not None
    }

    if not constraints:
        return base

    annotated: Any = Annotated[str, StringConstraints(**constraints)]

    if "pattern" in constraints:
        try:
            TypeAdapter(annotated)
        except _PydanticSchemaError as exc:
            if "regex" not in str(exc).lower():
                raise
            pattern = constraints.pop("pattern")
            warnings.warn(
                f"Pattern {pattern!r} is not supported by Pydantic's regex engine "
                f"and will not be enforced.",
                UserWarning,
                stacklevel=2,
            )
            pattern_field = Field(json_schema_extra={"x-unsupported-pattern": pattern})
            if constraints:
                annotated = Annotated[
                    str, StringConstraints(**constraints), pattern_field
                ]  # type: ignore[valid-type]
            else:
                annotated = Annotated[str, pattern_field]  # type: ignore[valid-type]

    if base is str:
        return annotated
    return _constrain_raw_string(base, **constraints)


@lru_cache(maxsize=1024)
def _constrain_raw_string(
    base: Any,
    min_length: int | None = None,
    max_length: int | None = None,
    pattern: str | None = None,
) -> Any:
    """Apply string keywords to the raw instance before `base` parses it, as JSON Schema does.

    Cached so a schema seen on every tool call maps to one type, and so one TypeAdapter.
    """
    raw = TypeAdapter(
        Annotated[
            str,
            StringConstraints(
                min_length=min_length, max_length=max_length, pattern=pattern
            ),
        ]
    )
    return Annotated[
        base,
        BeforeValidator(lambda v: raw.validate_python(v) if isinstance(v, str) else v),
    ]


def _exclusive_bound(schema: Mapping[str, Any], modifier: str, bound: str) -> Any:
    """Value for a strict bound, or None when the schema states no strict bound.

    ``exclusiveMinimum``/``exclusiveMaximum`` take a number since draft-06. Draft-04
    instead writes a boolean that tightens the numeric sibling: ``{"minimum": 1,
    "exclusiveMinimum": true}`` excludes 1. Passing that boolean straight through as
    Pydantic's ``gt``/``lt`` reads it as the number 1, which rejects every value
    except 0 regardless of the sibling.
    """
    value = schema.get(modifier)
    if isinstance(value, bool):
        return schema.get(bound) if value else None
    return value


def _inclusive_bound(
    schema: Mapping[str, Any], modifier: str, bound: str, *, lower: bool
) -> Any:
    """Value for a non-strict bound, or None when a strict bound replaces the sibling.

    A boolean ``true`` (draft-04) always replaces the sibling: ``{"minimum": 1,
    "exclusiveMinimum": true}`` means exactly ``minimum > 1``.

    A numeric ``exclusiveMinimum``/``exclusiveMaximum`` (draft-06+) is instead a
    separate keyword, and an instance must satisfy both. The sibling is redundant —
    and can be dropped — only when the exclusive bound is at least as strict, which
    compares ``exclusive >= minimum`` for a lower bound and ``exclusive <= maximum``
    for an upper one. A *looser* numeric exclusive must keep the sibling, otherwise
    the generated ``lt``/``gt`` widens the accepted range: ``{"maximum": 10,
    "exclusiveMaximum": 15}`` would accept 12.
    """
    value = schema.get(bound)
    exclusive = schema.get(modifier)
    if exclusive is True:
        return None
    if (
        isinstance(exclusive, (int, float))
        and not isinstance(exclusive, bool)
        and isinstance(value, (int, float))
        and not isinstance(value, bool)
        and (exclusive >= value if lower else exclusive <= value)
    ):
        return None
    return value


def _create_numeric_type(
    base: type[int | float], schema: Mapping[str, Any]
) -> type | Annotated[Any, ...]:
    """Create numeric type with optional constraints."""
    if "const" in schema:
        return Literal[schema["const"]]  # type: ignore

    constraints = {
        k: v
        for k, v in {
            "gt": _exclusive_bound(schema, "exclusiveMinimum", "minimum"),
            "ge": _inclusive_bound(schema, "exclusiveMinimum", "minimum", lower=True),
            "lt": _exclusive_bound(schema, "exclusiveMaximum", "maximum"),
            "le": _inclusive_bound(schema, "exclusiveMaximum", "maximum", lower=False),
            "multiple_of": schema.get("multipleOf"),
        }.items()
        if v is not None
    }

    return Annotated[base, Field(**constraints)] if constraints else base  # type: ignore[return-value]  # ty:ignore[invalid-type-form]


def _create_enum(name: str, values: list[Any]) -> Any:
    """Create enum type from list of values."""
    if not values:
        # Empty enum means no value is valid (same semantics as ``false``
        # schema).  Return the unsatisfiable type instead of ``Literal[()]``
        # which triggers an AssertionError in Pydantic.
        return _UnsatisfiableType
    # Always return Literal for enum fields to preserve the literal nature
    literal = Literal[tuple(values)]  # ty:ignore[invalid-type-form]
    if all(value is None or isinstance(value, str) for value in values):
        return literal

    try:
        hash(literal)
    except TypeError:
        hashable = False
    else:
        hashable = True

    # Pydantic matches Literal values with Python equality, so True would pass
    # for 1, also inside arrays and objects.
    def check(value: Any) -> Any:
        for allowed in values:
            if _json_values_equal(value, allowed):
                return allowed if hashable else value
        raise ValueError(f"Input should be one of {values!r}")

    if not hashable:
        # A Literal holding an object or array cannot be hashed into a Union.
        return Annotated[
            Any, BeforeValidator(check), Field(json_schema_extra={"enum": values})
        ]
    return Annotated[literal, PlainValidator(check, json_schema_input_type=literal)]


def _json_values_equal(left: Any, right: Any) -> bool:
    """Compare JSON values without treating booleans as numbers."""
    if isinstance(left, bool) or isinstance(right, bool):
        return isinstance(left, bool) and isinstance(right, bool) and left == right

    if isinstance(left, Mapping) or isinstance(right, Mapping):
        if not isinstance(left, Mapping) or not isinstance(right, Mapping):
            return False
        return left.keys() == right.keys() and all(
            _json_values_equal(left[key], right[key]) for key in left
        )

    if isinstance(left, (list, tuple)) or isinstance(right, (list, tuple)):
        if not isinstance(left, (list, tuple)) or not isinstance(right, (list, tuple)):
            return False
        return len(left) == len(right) and all(
            _json_values_equal(left_item, right_item)
            for left_item, right_item in zip(left, right, strict=True)
        )

    return left == right


def _json_value_key(value: Any) -> tuple[Any, ...]:
    """Build a hashable, type-tagged key for standard JSON values."""
    value_type = type(value)
    if value is None:
        return ("null",)
    if value_type is bool:
        return ("boolean", value)
    if value_type is int or value_type is float:
        if value_type is float and not math.isfinite(value):
            raise TypeError("Not a standard JSON number")
        # Equal ints/floats already share a hash, without rounding large ints.
        return ("number", value)
    if value_type is str:
        return ("string", value)
    if value_type is list:
        return ("array", tuple(_json_value_key(item) for item in value))
    if value_type is dict and all(type(key) is str for key in value):
        return (
            "object",
            frozenset((key, _json_value_key(item)) for key, item in value.items()),
        )
    raise TypeError("Not a standard JSON value")


def _validate_unique_items(value: Any) -> Any:
    """Reject duplicate JSON array items while preserving list semantics."""
    if not isinstance(value, (list, tuple)):
        return value

    try:
        seen: set[tuple[Any, ...]] = set()
        for item in value:
            key = _json_value_key(item)
            if key in seen:
                raise ValueError("Array items must be unique")
            seen.add(key)
    except (TypeError, RecursionError):
        # Preserve existing comparisons for non-JSON Python values, including
        # equality between those values and standard JSON values.
        for index, item in enumerate(value):
            if any(_json_values_equal(item, previous) for previous in value[:index]):
                raise ValueError("Array items must be unique") from None

    return value


def _create_prefix_items_type(
    prefix_types: tuple[Any, ...], item_type: Any, schema: Mapping[str, Any]
) -> Any:
    """Validate positions while preserving unrestricted-list compatibility."""
    minimum = _count(schema.get("minItems"))
    maximum = _count(schema.get("maxItems"), maximum=True)
    preserve_prefix_values = item_type is Any or item_type is object

    def preserve_value(
        value: Any, handler: core_schema.ValidatorFunctionWrapHandler
    ) -> Any:
        handler(value)
        return value

    def validate_list(
        value: Any, handler: core_schema.ValidatorFunctionWrapHandler
    ) -> list[Any]:
        if not isinstance(value, list):
            return list(handler(value))
        if minimum is not None and len(value) < minimum:
            raise ValueError(f"Array should have at least {minimum} items")
        if maximum is not None and len(value) > maximum:
            raise ValueError(f"Array should have at most {maximum} items")
        # Missing prefix positions are optional. Discard the defaults used by
        # the tuple validator instead of appending values to a shorter array.
        return list(handler(tuple(value))[: len(value)])

    def serialize_list(
        value: list[Any], handler: core_schema.SerializerFunctionWrapHandler
    ) -> list[Any]:
        return list(handler(tuple(value)))

    def build_schema(
        source: Any, handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        # Read the position types back from the annotation rather than this
        # closure: a recursive `$ref` is a ForwardRef until
        # `_resolve_recursive_types` evaluates the annotation, and only the
        # annotation's arguments are evaluated.
        positions_type, tail_type = get_args(source)
        resolved_prefix = get_args(positions_type)

        def build_positions(json_input: bool) -> core_schema.CoreSchema:
            def item_schema(item: Any) -> core_schema.CoreSchema:
                converted = handler.generate_schema(item)
                if json_input:
                    # A wrap handler receives Python values. Restore JSON input
                    # semantics so strict dates still accept JSON date strings.
                    return core_schema.no_info_before_validator_function(
                        json.dumps,
                        core_schema.json_schema(converted),
                        json_schema_input_schema=converted,
                    )
                return converted

            positions: list[core_schema.CoreSchema] = [
                core_schema.with_default_schema(
                    core_schema.no_info_wrap_validator_function(
                        preserve_value,
                        item_schema(position_type),
                        serialization=core_schema.simple_ser_schema("any"),
                    )
                    if preserve_prefix_values
                    else item_schema(position_type),
                    # A placeholder for a missing position, sliced off after
                    # validation; never validate it, whatever the enclosing
                    # model's validate_default says.
                    default=None,
                    validate_default=False,
                )
                for position_type in resolved_prefix
            ]
            positions.append(item_schema(tail_type))
            return core_schema.tuple_schema(
                positions,
                variadic_item_index=len(prefix_types),
                min_length=0,
            )

        positional_schema = build_positions(json_input=False)
        validated = core_schema.no_info_wrap_validator_function(
            validate_list, positional_schema
        )
        return core_schema.json_or_python_schema(
            json_schema=core_schema.no_info_wrap_validator_function(
                validate_list, build_positions(json_input=True)
            ),
            python_schema=core_schema.chain_schema(
                [core_schema.list_schema(), validated]
            ),
            serialization=core_schema.wrap_serializer_function_ser_schema(
                serialize_list, schema=positional_schema
            ),
        )

    def build_json_schema(
        core: core_schema.CoreSchema, handler: GetJsonSchemaHandler
    ) -> dict[str, Any]:
        result = handler(core)
        if minimum is not None:
            result["minItems"] = minimum
        if maximum is not None:
            result["maxItems"] = maximum
        for index, position in enumerate(result.get("prefixItems", [])):
            if prefix_types[index] is _UnsatisfiableType:
                result["prefixItems"][index] = False
            elif isinstance(position, dict):
                position.pop("default", None)
        if item_type is _UnsatisfiableType:
            result["items"] = False
        return result

    # The source type carries the position types so recursive references in
    # them are resolved; validation and the JSON schema come from build_schema.
    source = tuple[tuple[prefix_types], item_type]  # ty:ignore[invalid-type-form]
    return Annotated[source, GetPydanticSchema(build_schema, build_json_schema)]


def _create_array_type(
    schema: Mapping[str, Any],
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str],
) -> type | Annotated[Any, ...]:
    """Create list/tuple type with optional constraints."""
    prefix_items = schema.get("prefixItems")
    items = schema.get("items", {})
    if isinstance(prefix_items, list) and schema.get("minItems") == len(
        prefix_items
    ) == schema.get("maxItems"):
        # A positional schema (JSON Schema 2020-12) whose length is pinned to
        # the number of positions is an exact tuple — this is the shape a
        # fixed-length tuple annotation serializes to. Hydrate every position
        # from its own schema so positional items keep their types instead of
        # degrading to untyped objects.
        positional_types = tuple(
            _schema_to_type(s, schemas, resolving_refs) for s in prefix_items
        )
        base = tuple[positional_types]  # type: ignore[valid-type]  # ty:ignore[invalid-type-form]
    elif isinstance(prefix_items, list):
        prefix_types = tuple(
            _schema_to_type(s, schemas, resolving_refs) for s in prefix_items
        )
        item_type = _schema_to_type(items, schemas, resolving_refs)
        base = _create_prefix_items_type(prefix_types, item_type, schema)
        if schema.get("uniqueItems") is True:
            return Annotated[
                base,  # ty:ignore[invalid-type-form]
                BeforeValidator(_validate_unique_items),
                Field(json_schema_extra={"uniqueItems": True}),
            ]
        return base
    elif isinstance(items, list):
        # Handle positional item schemas
        item_types = [_schema_to_type(s, schemas, resolving_refs) for s in items]
        combined = Union[tuple(item_types)]  # noqa: UP007
        base = list[combined]  # type: ignore[valid-type]  # ty:ignore[invalid-type-form]
    else:
        # Handle single item schema
        item_type = _schema_to_type(items, schemas, resolving_refs)
        base = list[item_type]  # type: ignore[valid-type]  # ty:ignore[invalid-type-form]

    constraints = {
        k: v
        for k, v in {
            "min_length": _count(schema.get("minItems")),
            "max_length": _count(schema.get("maxItems"), maximum=True),
        }.items()
        if v is not None
    }

    if schema.get("uniqueItems") is True:
        constraints["json_schema_extra"] = {"uniqueItems": True}
        return Annotated[
            base,
            BeforeValidator(_validate_unique_items),
            Field(**constraints),
        ]  # type: ignore[return-value]

    return Annotated[base, Field(**constraints)] if constraints else base  # type: ignore[return-value]


def _return_Any() -> Any:
    return Any


def _object_schema_to_type(
    schema: Mapping[str, Any],
    schemas: Mapping[str, Any],
    name: str | None = None,
    resolving_refs: frozenset[str] = frozenset(),
) -> type:
    """Convert an object schema to the appropriate Python type.

    Single source of truth for the four object-schema cases, used by both the
    top-level ``json_schema_to_type`` entry point and the recursive
    ``_schema_to_type`` path:

    1. No ``properties`` with ``additionalProperties`` truthy — ``dict[str, T]``
       (``T = Any`` when ``additionalProperties is True``, else the value schema's type)
    2. No ``properties`` and no ``additionalProperties`` — ``dict[str, Any]``
    3. Has ``properties`` and ``additionalProperties`` is true or a schema —
       Pydantic model (so extra keys can be preserved and hydrated)
    4. Has ``properties`` otherwise — dataclass

    ``name`` is used as the generated class name for cases 3 and 4; it falls
    back to the schema's ``title`` when not provided.
    """
    has_properties = bool(schema.get("properties"))
    additional_props = schema.get("additionalProperties")
    class_name = name if name is not None else _schema_title(schema)

    if not has_properties and additional_props:
        if additional_props is True:
            return dict[str, Any]
        value_type = _schema_to_type(additional_props, schemas, resolving_refs)
        return cast(type[Any], dict[str, value_type])  # type: ignore[valid-type]  # ty:ignore[invalid-type-form]

    if not has_properties and not additional_props:
        return dict[str, Any]

    if has_properties and (
        additional_props is True or isinstance(additional_props, Mapping)
    ):
        return _create_pydantic_model(schema, class_name, schemas, resolving_refs)

    return _create_dataclass(schema, class_name, schemas, resolving_refs)


def _get_from_type_handler(
    schema: Mapping[str, Any],
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str],
) -> Callable[..., Any]:
    """Get the appropriate type handler for the schema."""

    type_handlers: dict[str, Callable[..., Any]] = {
        "string": lambda s: _create_string_type(s),
        "integer": lambda s: _create_numeric_type(int, s),
        "number": lambda s: _create_numeric_type(float, s),
        "boolean": lambda _: bool,
        "null": lambda _: type(None),
        "array": lambda s: _create_array_type(s, schemas, resolving_refs),
        "object": lambda s: _object_schema_to_type(
            s, schemas, resolving_refs=resolving_refs
        ),
    }
    return type_handlers.get(schema.get("type", None), _return_Any)


def _schema_to_type(
    schema: Mapping[str, Any] | bool,
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str] = frozenset(),
) -> type | ForwardRef:
    """Convert schema to appropriate Python type, within the conversion limits."""
    conversion = _conversion.get()
    conversion.steps += 1
    if conversion.depth >= _MAX_CONVERSION_DEPTH:
        raise ValueError("JSON schema is too deeply nested to convert")
    if conversion.steps > _MAX_CONVERSION_STEPS:
        raise ValueError("JSON schema is too large to convert")
    conversion.depth += 1
    try:
        return _convert_schema(schema, schemas, resolving_refs)
    finally:
        conversion.depth -= 1


def _convert_schema(
    schema: Mapping[str, Any] | bool,
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str],
) -> type | ForwardRef:
    # Boolean schemas are valid in JSON Schema draft-06+:
    # true means "any value is valid" (equivalent to {}),
    # false means "no value is valid" (unsatisfiable).
    if schema is True:
        return Any
    if schema is False:
        return _UnsatisfiableType  # type: ignore[return-value]  # ty:ignore[invalid-return-type]

    if not schema:
        return object

    if "type" not in schema and "properties" in schema:
        # A schema with properties but no "type" is still an object schema. When
        # it allows additional properties, take the object path so unknown keys
        # are kept, exactly as if "type": "object" were spelled out.
        if schema.get("additionalProperties"):
            return _object_schema_to_type(
                schema, schemas, resolving_refs=resolving_refs
            )
        return _create_dataclass(schema, _schema_title(schema, "<unknown>"), schemas)

    # Handle references first
    if "$ref" in schema:
        ref = schema["$ref"]
        # Handle self-reference
        if ref == "#":
            conversion = _conversion.get()
            return ForwardRef(
                conversion.root_class_name
                or conversion.enclosing_class_name
                or _sanitize_name(_schema_title(schema, "Root"))
            )
        if ref in resolving_refs:
            resolved = _resolve_ref(ref, schemas)
            if isinstance(resolved, Mapping) and (
                resolved.get("type") == "object" or "properties" in resolved
            ):
                return _schema_to_type(resolved, schemas, resolving_refs)
            return Any
        # Convert each reference once per conversion, so a definition shared
        # by many references is not expanded again for every path to it.
        resolved_refs = _conversion.get().resolved_refs
        if ref not in resolved_refs:
            resolved_refs[ref] = _schema_to_type(
                _resolve_ref(ref, schemas), schemas, resolving_refs | {ref}
            )
        return resolved_refs[ref]

    if "const" in schema:
        return _create_enum(f"Const_{len(_classes)}", [schema["const"]])

    if "enum" in schema:
        return _create_enum(f"Enum_{len(_classes)}", schema["enum"])

    # Handle anyOf unions
    if "anyOf" in schema:
        types: list[type | Any] = [
            _schema_to_type(subschema, schemas, resolving_refs)
            for subschema in schema["anyOf"]
        ]

        # Check if one of the types is None (null)
        has_null = type(None) in types
        types = [t for t in types if t is not type(None)]

        if len(types) == 0:
            return type(None)
        elif len(types) == 1:
            if has_null:
                return Union[types[0], type(None)]  # type: ignore # noqa: UP007
            else:
                return types[0]
        else:
            if has_null:
                return Union[(*types, type(None))]  # type: ignore
            else:
                return Union[tuple(types)]  # type: ignore # noqa: UP007

    schema_type = schema.get("type")
    if not schema_type:
        return Any

    if isinstance(schema_type, list):
        # Create a copy of the schema for each type, but keep all constraints
        types: list[type | Any] = []
        for t in schema_type:
            if t == "object" and schema is schemas:
                # The root narrowed to its object member: convert the schema
                # itself, not a copy, so the generated class keeps the root
                # identity (and name) that "$ref": "#" resolves to.
                types.append(
                    _object_schema_to_type(
                        schema, schemas, resolving_refs=resolving_refs
                    )
                )
                continue
            type_schema = dict(schema)
            type_schema["type"] = t
            types.append(_schema_to_type(type_schema, schemas, resolving_refs))
        has_null = type(None) in types
        types = [t for t in types if t is not type(None)]
        if has_null:
            if len(types) == 1:
                return Union[types[0], type(None)]  # type: ignore # noqa: UP007
            else:
                return Union[(*types, type(None))]  # type: ignore
        return Union[tuple(types)]  # type: ignore # noqa: UP007

    return _get_from_type_handler(schema, schemas, resolving_refs)(schema)


@overload
def _schema_title(schema: Mapping[str, Any], default: str) -> str: ...
@overload
def _schema_title(schema: Mapping[str, Any], default: None = None) -> str | None: ...
def _schema_title(schema: Mapping[str, Any], default: str | None = None) -> str | None:
    """Return the schema's `title` when it can name a class, else `default`.

    `title` can carry any JSON value in a malformed schema; only a string
    (including the empty string) is a valid class-name source.
    """
    title = schema.get("title")
    return title if isinstance(title, str) else default


def _sanitize_name(name: str) -> str:
    """Convert string to valid Python identifier."""
    original_name = name
    # Step 1: replace everything except [0-9a-zA-Z_] with underscores
    cleaned = re.sub(r"[^0-9a-zA-Z_]", "_", name)
    # Step 2: deduplicate underscores
    cleaned = re.sub(r"__+", "_", cleaned)
    # Step 3: if the first char of original name isn't a letter or underscore, prepend field_
    if not name or not re.match(r"[a-zA-Z_]", name[0]):
        cleaned = f"field_{cleaned}"
    # Step 4: deduplicate again
    cleaned = re.sub(r"__+", "_", cleaned)
    # Step 5: only strip trailing underscores if they weren't in the original name
    if not original_name.endswith("_"):
        cleaned = cleaned.rstrip("_")
    # Step 6: if result is a Python keyword, append an underscore (PEP 8 convention)
    if keyword.iskeyword(cleaned):
        cleaned = f"{cleaned}_"
    return cleaned


_BASE_MODEL_MEMBERS = frozenset(dir(BaseModel))


def _is_reserved_field_name(name: str) -> bool:
    """Whether a property name would act as a class or Pydantic control name.

    Leading underscores cover dunders, Pydantic private attributes, and the
    `create_model` keyword arguments. Members in the `model_` namespace are
    Pydantic's own API.
    """
    return name.startswith("_") or (
        name.startswith("model_") and name in _BASE_MODEL_MEMBERS
    )


def safe_create_model(
    name: str,
    field_definitions: Mapping[str, tuple[Any, Any]],
    *,
    config: ConfigDict | None = None,
    extra_value_type: Any = None,
) -> type[BaseModel]:
    """Create a Pydantic model whose field names come from untrusted input.

    Each property name only ever becomes a field. A reserved name is stored
    under a generated field name with the original name as its alias, so it
    validates and dumps (with `by_alias=True`) under its original name.

    Args:
        name: The model class name.
        field_definitions: Maps each property name to `(annotation, default)`,
            where `default` may be a `FieldInfo` or `...` for required fields.
        config: Optional model configuration.
        extra_value_type: Optional annotation for values of additional properties.
    """
    fields: dict[str, Any] = {}
    for prop_name, (annotation, default) in field_definitions.items():
        field_name = prop_name
        if _is_reserved_field_name(prop_name):
            base = f"field_{_sanitize_name(prop_name).lstrip('_')}"
            field_name = base
            counter = 2
            while field_name in fields or field_name in field_definitions:
                field_name = f"{base}_{counter}"
                counter += 1
            if isinstance(default, FieldInfo):
                annotation = Annotated[annotation, default]
                default = Field(alias=prop_name)
            else:
                default = Field(default=default, alias=prop_name)
        fields[field_name] = (annotation, default)
    if extra_value_type is not None:
        fields["__pydantic_extra__"] = (dict[str, extra_value_type], Field(init=False))
    return create_model(name, __config__=config, **fields)


def _get_default_value(
    schema: dict[str, Any],
    prop_name: str,
    parent_default: dict[str, Any] | None = None,
) -> Any:
    """Get default value with proper priority ordering.
    1. Value from parent's default if it exists
    2. Property's own default if it exists
    3. None
    """
    if parent_default is not None and prop_name in parent_default:
        return parent_default[prop_name]
    return schema.get("default")


def _create_field_with_default(
    field_type: type,
    default_value: Any,
    schema: dict[str, Any],
) -> Any:
    """Create a field with simplified default handling."""
    # Always use None as default for complex types
    if isinstance(default_value, dict | list) or default_value is None:
        return field(default=None)

    # For simple types, use the value directly
    return field(default=default_value)


def _nested_class_name(
    sanitized_name: str,
    conversion: _Conversion,
    schema: Mapping[str, Any],
    schemas: Mapping[str, Any] | None,
) -> str:
    """Disambiguate a nested class named like the conversion root.

    Pydantic resolves a class's annotations with the class's own name bound
    to that class before the conversion root, so a nested class sharing the
    root's name would capture every ``"$ref": "#"`` reference inside it.
    Keep the root name pointing at the root class.
    """
    if sanitized_name == conversion.root_class_name and schema is not schemas:
        return f"{sanitized_name}_2"
    return sanitized_name


def _create_pydantic_model(
    schema: Mapping[str, Any],
    name: str | None = None,
    schemas: Mapping[str, Any] | None = None,
    resolving_refs: frozenset[str] = frozenset(),
) -> type:
    """Create Pydantic BaseModel from object schema with additionalProperties."""
    name = name or _schema_title(schema, "Root")
    if name is None:
        raise ValueError("Name is required")
    sanitized_name = _sanitize_name(name)
    conversion = _conversion.get()
    sanitized_name = _nested_class_name(sanitized_name, conversion, schema, schemas)
    schema_hash = _hash_schema(schema)
    # Nested classes bake the root class name into their forward references,
    # so conversions that differ only in the root's name must not share
    # cache entries.
    cache_key = (
        schema_hash + conversion.root_hash + (conversion.root_class_name or ""),
        sanitized_name,
    )

    # Return existing class if already built
    existing = conversion.classes.get(cache_key) or _classes.get(cache_key)
    if existing is not None:
        return existing
    # A recursive reference to a class that is still being built
    if cache_key in conversion.building:
        return conversion.reference(cache_key)  # type: ignore[return-value]  # ty:ignore[invalid-return-type]

    conversion.building.add(cache_key)
    enclosing_class_name = conversion.enclosing_class_name
    conversion.enclosing_class_name = sanitized_name
    try:
        cls = _build_pydantic_model(
            schema, sanitized_name, schemas or {}, resolving_refs
        )
    finally:
        conversion.enclosing_class_name = enclosing_class_name
        conversion.building.discard(cache_key)
    conversion.classes[cache_key] = cls
    return cls


def _build_pydantic_model(
    schema: Mapping[str, Any],
    name: str,
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str],
) -> type:
    properties = schema.get("properties", {})
    required = schema.get("required", [])

    field_definitions: dict[str, tuple[Any, Any]] = {}
    unchecked: list[str] = []
    for prop_name, prop_schema in properties.items():
        # Boolean schemas (JSON Schema draft-06+): resolve type directly,
        # then use an empty dict for .get() calls below.
        if isinstance(prop_schema, bool):
            field_type = _schema_to_type(prop_schema, schemas, resolving_refs)
            prop_schema = {}
        elif prop_schema.get("$ref") == "#":
            field_type = ForwardRef(_conversion.get().root_class_name or name)
        else:
            field_type = _schema_to_type(prop_schema, schemas, resolving_refs)

        # Handle defaults
        default_value = prop_schema.get("default", MISSING)
        if default_value is not MISSING:
            # Check if the default value is valid against the field type.
            # Only set validate_default=True when it passes, so that:
            # 1. Valid defaults get hydrated (e.g., date strings → date objects)
            # 2. Invalid defaults are preserved as-is rather than causing
            #    validation errors that would be caught and logged during parsing
            validate_default = _default_is_valid(field_type, default_value)
            if not validate_default:
                unchecked.append(prop_name)
            field_definitions[prop_name] = (
                field_type,
                Field(default=default_value, validate_default=validate_default),
            )
        elif prop_name in required:
            field_definitions[prop_name] = (field_type, ...)
        else:
            field_definitions[prop_name] = (Union[field_type, type(None)], None)  # type: ignore[misc]  # noqa: UP007  # ty:ignore[invalid-type-form]

    additional_props = schema.get("additionalProperties")
    extra_value_type = None
    if isinstance(additional_props, Mapping):
        extra_value_type = _schema_to_type(additional_props, schemas, resolving_refs)
    model = safe_create_model(
        name,
        field_definitions,
        config=ConfigDict(extra="allow", validate_default=extra_value_type is not None),
        extra_value_type=extra_value_type,
    )
    conversion = _conversion.get()
    conversion.unchecked_defaults.extend((model, prop) for prop in unchecked)
    return model


def _create_dataclass(
    schema: Mapping[str, Any],
    name: str | None = None,
    schemas: Mapping[str, Any] | None = None,
    resolving_refs: frozenset[str] = frozenset(),
) -> type:
    """Create dataclass from object schema."""
    name = name or _schema_title(schema, "Root")
    # Sanitize name for class creation
    if name is None:
        raise ValueError("Name is required")
    sanitized_name = _sanitize_name(name)
    conversion = _conversion.get()
    sanitized_name = _nested_class_name(sanitized_name, conversion, schema, schemas)
    schema_hash = _hash_schema(schema)
    # Nested classes bake the root class name into their forward references,
    # so conversions that differ only in the root's name must not share
    # cache entries.
    cache_key = (
        schema_hash + conversion.root_hash + (conversion.root_class_name or ""),
        sanitized_name,
    )

    # Return existing class if already built
    existing = conversion.classes.get(cache_key) or _classes.get(cache_key)
    if existing is not None:
        return existing
    # A recursive reference to a class that is still being built
    if cache_key in conversion.building:
        return conversion.reference(cache_key)  # type: ignore[return-value]  # ty:ignore[invalid-return-type]

    conversion.building.add(cache_key)
    enclosing_class_name = conversion.enclosing_class_name
    conversion.enclosing_class_name = sanitized_name
    try:
        cls = _build_dataclass(schema, sanitized_name, schemas or {}, resolving_refs)
    finally:
        conversion.enclosing_class_name = enclosing_class_name
        conversion.building.discard(cache_key)
    if isinstance(cls, type):
        conversion.classes[cache_key] = cls
    return cls


def _build_dataclass(
    schema: Mapping[str, Any],
    sanitized_name: str,
    schemas: Mapping[str, Any],
    resolving_refs: frozenset[str],
) -> Any:
    original_schema = dict(schema)  # Store copy for validator

    if "$ref" in schema:
        ref = schema["$ref"]
        if ref == "#":
            # "#" resolves to the conversion root, not to this class.
            return ForwardRef(_conversion.get().root_class_name or sanitized_name)
        if ref in resolving_refs:
            return Any
        schema = _resolve_ref(ref, schemas)
        resolving_refs = resolving_refs | {ref}

    properties = schema.get("properties", {})
    required = schema.get("required", [])

    fields: list[tuple[Any, ...]] = []
    unchecked: list[str] = []
    used_field_names: set[str] = set()
    for prop_name, prop_schema in properties.items():
        field_name = _sanitize_name(prop_name)
        # Deduplicate: if sanitized names collide (e.g. "foo-bar" and
        # "foo_bar" both become "foo_bar"), append a numeric suffix.
        base = field_name
        counter = 2
        while field_name in used_field_names:
            field_name = f"{base}_{counter}"
            counter += 1
        used_field_names.add(field_name)

        # Boolean schemas (JSON Schema draft-06+): resolve type directly,
        # then use an empty dict for .get() calls below.
        if isinstance(prop_schema, bool):
            field_type = _schema_to_type(prop_schema, schemas, resolving_refs)
            prop_schema = {}
        elif prop_schema.get("$ref") == "#":
            # A direct "#" reference points at the conversion root, which
            # may be a different class than the one being built here.
            field_type = ForwardRef(_conversion.get().root_class_name or sanitized_name)
        else:
            field_type = _schema_to_type(prop_schema, schemas, resolving_refs)

        default_val = prop_schema.get("default", MISSING)
        is_required = prop_name in required

        # Include alias in field metadata
        meta: dict[str, Any] = {"alias": prop_name}

        if default_val is not MISSING:
            # Only valid defaults are validated (and hydrated); invalid ones
            # are kept as-is, matching the model path.
            meta["validate_default"] = _default_is_valid(field_type, default_val)
            if not meta["validate_default"]:
                unchecked.append(field_name)
            if isinstance(default_val, dict | list):
                field_def = field(
                    default_factory=lambda d=default_val: deepcopy(d), metadata=meta
                )
            else:
                field_def = field(default=default_val, metadata=meta)
        else:
            if is_required:
                field_def = field(metadata=meta)
            else:
                field_def = field(default=None, metadata=meta)

        if is_required or default_val is not MISSING:
            fields.append((field_name, field_type, field_def))
        else:
            fields.append((field_name, Union[field_type, type(None)], field_def))  # type: ignore[misc]  # noqa: UP007  # ty:ignore[invalid-type-form]

    cls = make_dataclass(sanitized_name, fields, kw_only=True)

    # Add model validator for defaults
    @model_validator(mode="wrap")
    @classmethod
    def _apply_defaults(cls, data: Any, handler: ValidatorFunctionWrapHandler):
        if not isinstance(data, dict):
            return handler(data)
        # Omitted fields fall back to the field defaults, which validate only
        # when valid; object defaults are still merged here.
        merged = _merge_defaults(data, original_schema, apply_property_defaults=False)
        try:
            return handler(merged)
        except ValidationError as e:
            # `default` is an annotation, not a constraint. When a merged-in
            # default is what fails, keep the caller's value for that property
            # and leave every other merge in place. Errors in the caller's own
            # data are raised as they are, so each level validates at most
            # twice and only when a default caused the failure.
            added = _merged_in_paths(merged, data)
            broken: set[str] = {
                str(loc[0])
                for err in e.errors()
                if (loc := err["loc"]) and any(loc[: len(a)] == a for a in added)
            }
            if not broken:
                raise
            kept = {k: v for k, v in merged.items() if k not in broken or k in data}
            for key in broken & data.keys():
                kept[key] = data[key]
            return handler(kept)

    cls._apply_defaults = _apply_defaults  # type: ignore[attr-defined]  # ty:ignore[missing-attribute]
    _conversion.get().unchecked_defaults.extend((cls, f) for f in unchecked)
    return cls


def _merged_in_paths(
    merged: Mapping[str, Any], data: Mapping[str, Any], prefix: tuple = ()
) -> list[tuple]:
    """Paths of keys that `_merge_defaults` added to the caller's data."""
    paths: list[tuple] = []
    for key, value in merged.items():
        if key not in data:
            paths.append((*prefix, key))
        elif isinstance(value, Mapping) and isinstance(data[key], Mapping):
            paths.extend(_merged_in_paths(value, data[key], (*prefix, key)))
    return paths


def _merge_defaults(
    data: Mapping[str, Any],
    schema: Mapping[str, Any],
    parent_default: Mapping[str, Any] | None = None,
    *,
    apply_property_defaults: bool = True,
) -> dict[str, Any]:
    """Merge defaults with provided data at all levels."""
    # If we have no data
    if not data:
        # Start with parent default if available
        if parent_default:
            result = dict(parent_default)
        # Otherwise use schema default if it is an object to merge
        elif isinstance(schema.get("default"), Mapping):
            result = dict(schema["default"])
        # Otherwise start empty
        else:
            result = {}
    # If we have data and a parent default, merge them
    elif parent_default:
        result = dict(parent_default)
        for key, value in data.items():
            if (
                isinstance(value, dict)
                and key in result
                and isinstance(result[key], dict)
            ):
                # recursively merge nested dicts
                result[key] = _merge_defaults(value, {"properties": {}}, result[key])
            else:
                result[key] = value
    # Otherwise just use the data
    else:
        result = dict(data)

    # For each property in the schema
    for prop_name, prop_schema in schema.get("properties", {}).items():
        # Normalize boolean schemas (JSON Schema draft-06+)
        if isinstance(prop_schema, bool):
            continue

        # If property is missing, apply defaults in priority order
        if apply_property_defaults and prop_name not in result:
            if parent_default and prop_name in parent_default:
                result[prop_name] = parent_default[prop_name]
            elif "default" in prop_schema:
                result[prop_name] = prop_schema["default"]

        # If property exists and is an object, recursively merge
        if (
            prop_name in result
            and isinstance(result[prop_name], dict)
            and prop_schema.get("type") == "object"
        ):
            # Get the appropriate default for this nested object
            nested_default = None
            if parent_default and prop_name in parent_default:
                nested_default = parent_default[prop_name]
            elif "default" in prop_schema:
                nested_default = prop_schema["default"]
            # `default` is an annotation and need not match the property's
            # type; only an object default has keys to merge.
            if not isinstance(nested_default, Mapping):
                nested_default = None

            result[prop_name] = _merge_defaults(
                result[prop_name],
                prop_schema,
                nested_default,
                apply_property_defaults=apply_property_defaults,
            )

    return result
