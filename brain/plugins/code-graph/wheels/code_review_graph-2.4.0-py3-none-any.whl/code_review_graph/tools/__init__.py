"""MCP tool definitions for the Code Review Graph server.

Exposes 30 tools (each registered in main.py with a ``_tool`` suffix):
1. build_or_update_graph  - full or incremental build
2. get_impact_radius      - blast radius from changed files
3. query_graph            - predefined graph queries
4. get_review_context     - focused subgraph + review prompt
5. semantic_search_nodes  - keyword + vector search across nodes
6. list_graph_stats       - aggregate statistics
7. embed_graph            - compute vector embeddings for semantic search
8. get_docs_section       - token-optimized documentation retrieval
9. find_large_functions   - find oversized functions/classes by line count
10. list_flows            - list execution flows sorted by criticality
11. get_flow              - get details of a single execution flow
12. get_affected_flows    - find flows affected by changed files
13. list_communities      - list detected code communities
14. get_community         - get details of a single community
15. get_architecture_overview - architecture overview from community structure
16. detect_changes        - risk-scored change impact analysis for code review
17. refactor_tool         - unified refactoring (rename preview, dead code, suggestions)
18. apply_refactor_tool   - apply a previously previewed refactoring
19. generate_wiki         - generate markdown wiki from community structure
20. get_wiki_page         - retrieve a specific wiki page
21. list_repos            - list registered repositories
22. cross_repo_search     - search registered repositories, all or a named subset
23. get_hub_nodes         - find most connected nodes (architectural hotspots)
24. get_bridge_nodes      - find architectural chokepoints (betweenness centrality)
25. get_knowledge_gaps    - identify structural weaknesses
26. get_surprising_connections - find unexpected architectural coupling
27. get_suggested_questions - auto-generated review questions from graph analysis
28. traverse_graph        - BFS/DFS traversal from best-matching node
29. run_postprocess       - flows, communities and FTS for an existing graph
30. get_minimal_context   - compact task-scoped entry point (call this first)
"""

from __future__ import annotations

import importlib
from typing import Any

_LAZY_EXPORTS: dict[str, tuple[str, str]] = {
    # Re-export names that external code may patch via "code_review_graph.tools.*"
    "parse_diff_ranges": ("..changes", "parse_diff_ranges"),
    "parse_git_diff_ranges": ("..changes", "parse_git_diff_ranges"),
    "parse_svn_diff_ranges": ("..changes", "parse_svn_diff_ranges"),
    "get_changed_files": ("..incremental", "get_changed_files"),
    "get_staged_and_unstaged": ("..incremental", "get_staged_and_unstaged"),
    # _common
    "_BUILTIN_CALL_NAMES": ("._common", "_BUILTIN_CALL_NAMES"),
    "_get_store": ("._common", "_get_store"),
    "_validate_repo_root": ("._common", "_validate_repo_root"),
    "with_provenance": ("._common", "with_provenance"),
    # analysis_tools
    "get_bridge_nodes_func": (".analysis_tools", "get_bridge_nodes_func"),
    "get_hub_nodes_func": (".analysis_tools", "get_hub_nodes_func"),
    "get_knowledge_gaps_func": (".analysis_tools", "get_knowledge_gaps_func"),
    "get_suggested_questions_func": (".analysis_tools", "get_suggested_questions_func"),
    "get_surprising_connections_func": (".analysis_tools", "get_surprising_connections_func"),
    # build
    "build_or_update_graph": (".build", "build_or_update_graph"),
    "run_postprocess": (".build", "run_postprocess"),
    # community_tools
    "get_architecture_overview_func": (".community_tools", "get_architecture_overview_func"),
    "get_community_func": (".community_tools", "get_community_func"),
    "list_communities_func": (".community_tools", "list_communities_func"),
    # context
    "get_minimal_context": (".context", "get_minimal_context"),
    # docs
    "embed_graph": (".docs", "embed_graph"),
    "generate_wiki_func": (".docs", "generate_wiki_func"),
    "get_docs_section": (".docs", "get_docs_section"),
    "get_wiki_page_func": (".docs", "get_wiki_page_func"),
    # flows_tools
    "get_flow": (".flows_tools", "get_flow"),
    "list_flows": (".flows_tools", "list_flows"),
    # query
    "find_large_functions": (".query", "find_large_functions"),
    "get_impact_radius": (".query", "get_impact_radius"),
    "list_graph_stats": (".query", "list_graph_stats"),
    "query_graph": (".query", "query_graph"),
    "semantic_search_nodes": (".query", "semantic_search_nodes"),
    "traverse_graph_func": (".query", "traverse_graph_func"),
    # refactor_tools
    "apply_refactor_func": (".refactor_tools", "apply_refactor_func"),
    "refactor_func": (".refactor_tools", "refactor_func"),
    # registry_tools
    "cross_repo_search_func": (".registry_tools", "cross_repo_search_func"),
    "list_repos_func": (".registry_tools", "list_repos_func"),
    # review
    "detect_changes_func": (".review", "detect_changes_func"),
    "get_affected_flows_func": (".review", "get_affected_flows_func"),
    "get_review_context": (".review", "get_review_context"),
}

__all__ = [
    # _common
    "_BUILTIN_CALL_NAMES",
    "_get_store",
    "_validate_repo_root",
    "with_provenance",
    # build
    "build_or_update_graph",
    "run_postprocess",
    # context
    "get_minimal_context",
    # community_tools
    "get_architecture_overview_func",
    "get_community_func",
    "list_communities_func",
    # docs
    "embed_graph",
    "generate_wiki_func",
    "get_docs_section",
    "get_wiki_page_func",
    # flows_tools
    "get_flow",
    "list_flows",
    # query
    "find_large_functions",
    "get_impact_radius",
    "list_graph_stats",
    "query_graph",
    "semantic_search_nodes",
    "traverse_graph_func",
    # refactor_tools
    "apply_refactor_func",
    "refactor_func",
    # registry_tools
    "cross_repo_search_func",
    "list_repos_func",
    # review
    "detect_changes_func",
    "get_affected_flows_func",
    "get_review_context",
    # analysis_tools
    "get_bridge_nodes_func",
    "get_hub_nodes_func",
    "get_knowledge_gaps_func",
    "get_suggested_questions_func",
    "get_surprising_connections_func",
    # Re-exported helpers
    "parse_diff_ranges",
    "parse_git_diff_ranges",
    "parse_svn_diff_ranges",
    "get_changed_files",
    "get_staged_and_unstaged",
]


def __getattr__(name: str) -> Any:
    target = _LAZY_EXPORTS.get(name)
    if target is not None:
        mod_path, attr = target
        mod = importlib.import_module(mod_path, __name__)
        val = getattr(mod, attr)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
