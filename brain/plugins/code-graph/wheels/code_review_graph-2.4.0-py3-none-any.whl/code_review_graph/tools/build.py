"""Tool 1: build_or_update_graph + run_postprocess."""

from __future__ import annotations

import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

from ..build_state import (
    BUILD_COMPLETE,
    BUILD_IN_PROGRESS,
    BUILD_STATE_KEY,
    INCOMPLETE_BUILD_STATES,
    POSTPROCESS_PENDING,
    advance_to_postprocess_pending,
    graph_contents_are_complete,
    read_build_state,
)
from ..constants import normalize_file_path
from ..incremental import (
    VERIFIED_FILE_COUNT_KEY,
    _prepare_db_path,
    collect_all_files,
    detect_vcs,
    full_build,
    get_all_tracked_files,
    get_db_path,
    incremental_update,
    resolve_incremental_base,
)
from ..locking import WriteLock, write_lock_path
from ._common import _get_store, _resolve_root

logger = logging.getLogger(__name__)

_PARTIAL_GRAPH_MIN_FILES = 8
_PARTIAL_GRAPH_MAX_COVERAGE = 0.25
_PARTIAL_GRAPH_SUSPECT_TRACKED_COVERAGE = 0.50


def _should_rebuild_partial_graph(
    repo_root: Path,
    store: Any,
    recurse_submodules: bool | None = None,
) -> bool:
    """Detect a non-empty graph that represents only a small slice of a repo."""
    if store.get_metadata("intentionally_incomplete") == "1":
        return False

    represented_paths = {
        normalize_file_path(path) for path in store.get_all_files()
    }
    # A graph that still holds what a complete graph held is not partial, even
    # if most parseable files yield no rows. This needs no inventory at all.
    try:
        verified = int(store.get_metadata(VERIFIED_FILE_COUNT_KEY) or 0)
    except ValueError:
        verified = 0
    if verified and len(represented_paths) > verified * _PARTIAL_GRAPH_MAX_COVERAGE:
        return False
    # Listing an SVN working copy asks the server, which no update should wait
    # for. The poisoned graphs this recovers came from Git diffs.
    if detect_vcs(repo_root) == "svn":
        return False

    tracked_files = get_all_tracked_files(repo_root, recurse_submodules)
    tracked_paths: set[str] = set()
    if tracked_files:
        # Keep the common path cheap: a graph already representing at least
        # half of all tracked files cannot be severely partial. Below that,
        # documentation- or asset-heavy repositories still need the precise
        # parseable inventory below before forcing an expensive rebuild.
        # Untracked files are indexed too, but say nothing about tracked ones.
        tracked_paths = {
            normalize_file_path(repo_root / relative) for relative in tracked_files
        }
        if (
            len(represented_paths & tracked_paths) >= len(tracked_files)
            * _PARTIAL_GRAPH_SUSPECT_TRACKED_COVERAGE
        ):
            return False
        if len(tracked_files) < _PARTIAL_GRAPH_MIN_FILES:
            return False

    expected_files = collect_all_files(repo_root, recurse_submodules)
    if len(expected_files) < _PARTIAL_GRAPH_MIN_FILES:
        return False

    expected_paths = {
        normalize_file_path(repo_root / relative)
        for relative in expected_files
    }
    # collect_all_files also lists untracked files, which say nothing about
    # whether the tracked ones made it into the graph.
    if tracked_paths:
        expected_paths &= tracked_paths
    represented_count = len(expected_paths & represented_paths)
    if represented_count <= len(expected_paths) * _PARTIAL_GRAPH_MAX_COVERAGE:
        return True
    # Checked and fine: later updates need not repeat the inventory.
    store.set_metadata(VERIFIED_FILE_COUNT_KEY, str(len(represented_paths)))
    return False


# The build-state vocabulary is imported above rather than defined here:
# ``full_build`` has to advance it as soon as the last file is stored, and it
# cannot import this module without a cycle. See
# :mod:`code_review_graph.build_state` for what each state means.


def build_was_interrupted(store: Any) -> bool:
    """True when the last build left source or derived data incomplete."""
    return read_build_state(store) in INCOMPLETE_BUILD_STATES


def _run_embedding_refresh(
    store: Any,
    result: dict[str, Any],
    warnings: list[str],
    *,
    provider: str | None,
    model: str | None,
) -> None:
    """Run a provider-scoped embedding refresh only when explicitly requested."""
    if provider is None and model is None:
        return
    if not provider or not model:
        warning = "Embedding refresh requires both an explicit provider and model."
        logger.warning(warning)
        warnings.append(warning)
        return
    try:
        from code_review_graph.embeddings import refresh_embeddings

        refreshed = refresh_embeddings(store, provider=provider, model=model)
        if refreshed is None:
            _report_refresh_skipped(result, warnings)
        else:
            result["embeddings_refreshed"] = refreshed["embedded"]
            result["embeddings_purged"] = refreshed["purged"]
    except Exception as exc:
        logger.warning("Embedding refresh failed: %s", exc)
        warnings.append(
            f"Embedding refresh failed: {type(exc).__name__}: {exc}",
        )


def _report_refresh_skipped(result: dict[str, Any], warnings: list[str]) -> None:
    """Tell a caller who asked for a refresh that the graph has no index to refresh."""
    from code_review_graph.embeddings import REFRESH_SKIPPED_WARNING

    logger.warning(REFRESH_SKIPPED_WARNING)
    warnings.append(REFRESH_SKIPPED_WARNING)
    result["embeddings_refresh_skipped"] = True


# SQLITE_BUSY and SQLITE_LOCKED are the only two primary result codes that
# mean "somebody else holds it, come back later".  Extended result codes carry
# their detail in the high bits, so the low byte is what identifies the family.
_CONTENTION_ERRORCODES = frozenset({5, 6})

# ``sqlite_errorcode`` arrived in Python 3.11 and is only set on exceptions the
# sqlite3 module itself raises, so the message is the fallback for 3.10 and for
# any error re-raised by our own code.
_CONTENTION_MESSAGES = (
    "database is locked",
    "database table is locked",
    "database schema is locked",
)


def is_lock_contention(exc: BaseException) -> bool:
    """True only for SQLite refusing a write because another process holds it.

    Every other ``sqlite3.OperationalError`` — a malformed statement, a disk
    I/O error, a read-only database file — is a genuine failure that the next
    run will hit again in exactly the same way.  The distinction is not
    cosmetic: contention deliberately leaves the ``build_state`` marker set so
    the next run redoes the lost stage, so classifying a permanent error as
    contention marks the graph incomplete forever and promotes every later
    update to a full rebuild that cannot clear it.
    """
    if not isinstance(exc, sqlite3.OperationalError):
        return False
    errorcode = getattr(exc, "sqlite_errorcode", None)
    if isinstance(errorcode, int):
        return (errorcode & 0xFF) in _CONTENTION_ERRORCODES
    message = str(exc).lower()
    return any(text in message for text in _CONTENTION_MESSAGES)


def _note_contention(build_result: dict[str, Any], exc: BaseException) -> None:
    """Classify a post-processing stage that failed.

    Contention is transient: another process held the SQLite write lock, and
    the next run can redo the stage, so the build-state marker stays set.  A
    genuine SQLite error is recorded separately — it downgrades the build to
    ``partial`` instead of being retried forever.  Anything else (a missing
    optional dependency, say) is left to the warning list alone: one absent
    extra must not pin the repository into permanent full rebuilds.
    """
    if not isinstance(exc, sqlite3.OperationalError):
        return
    if is_lock_contention(exc):
        build_result["postprocess_contended"] = True
    else:
        build_result["postprocess_failed"] = True


def _fts_file_hint(
    repo_root: str | None,
    changed_files: list[str] | None,
) -> list[str] | None:
    """Spell *changed_files* the way ``nodes.file_path`` stores them.

    Change discovery reports repository-relative paths while the graph keys
    nodes by their normalised absolute path. A hint that matches nothing is
    harmless (the delta still repairs every added and removed row) but it
    buys nothing either, so resolve it whenever the root is known.
    """
    if not changed_files:
        return None
    if repo_root is None:
        return [normalize_file_path(path) for path in changed_files]
    root = Path(repo_root)
    return [normalize_file_path(root / path) for path in changed_files]


def _run_postprocess(
    store: Any,
    build_result: dict[str, Any],
    postprocess: str,
    full_rebuild: bool = False,
    changed_files: list[str] | None = None,
    repo_root: str | None = None,
    embedding_provider: str | None = None,
    embedding_model: str | None = None,
    entry_point_qns: list[str] | None = None,
    communities_were_affected: bool = False,
    skip_resolvers: bool = False,
) -> list[str]:
    """Run post-build steps based on *postprocess* level.

    When *full_rebuild* is False and *changed_files* are available,
    uses incremental flow/community detection for faster updates.

    *skip_resolvers* leaves call-target resolution out, for a no-op update on a
    graph whose edges are already resolved.

    Records structured stage durations in ``build_result["postprocess_timing"]``.
    Minimal processing reports ``signatures_s`` and ``fts_s``; full processing
    additionally reports ``flows_s`` and ``communities_s``.
    Each duration is a nonnegative float measured in seconds.

    Returns a list of warning strings (empty on success).
    """
    warnings: list[str] = []
    build_result["postprocess_level"] = postprocess

    if postprocess == "none":
        _run_embedding_refresh(
            store,
            build_result,
            warnings,
            provider=embedding_provider,
            model=embedding_model,
        )
        # No resolver runs at this level, but edges were still written, so
        # the certainty column must not be left stale for the query layer.
        try:
            store.refresh_target_resolution()
        except sqlite3.OperationalError as e:
            logger.warning("Target-resolution refresh failed: %s", e)
            _note_contention(build_result, e)
            warnings.append(
                f"Target-resolution refresh failed: {type(e).__name__}: {e}"
            )
        return warnings

    noop_incremental = (
        not full_rebuild
        and changed_files is not None
        and build_result.get("files_updated") == 0
        and not build_result.get("stale_files_removed")
        # A C# rebind with no source change still owes the flows a rebuild.
        and store.get_metadata("csharp_flows_dirty") != "1"
    )

    # Resolve bare and C++ scoped call targets before derived graph steps.
    if not skip_resolvers:
        try:
            if noop_incremental and not store.get_nodes_without_signature():
                build_result["bare_edges_resolved"] = 0
                build_result["cpp_scoped_edges_resolved"] = 0
            else:
                noop_incremental = False
                resolved = store.resolve_bare_call_targets()
                resolved += store.resolve_bare_tested_by_sources()
                build_result["bare_edges_resolved"] = resolved
                build_result["cpp_scoped_edges_resolved"] = (
                    store.resolve_cpp_scoped_call_targets()
                )
                # Resolvers rewrite bare targets into qualified ones, so the stored
                # certainty column is only correct once they have all run.
                store.refresh_target_resolution()
        except sqlite3.OperationalError as e:
            logger.warning("Call-target resolution failed: %s", e)
            _note_contention(build_result, e)
            warnings.append(
                f"Call-target resolution failed: {type(e).__name__}: {e}"
            )

    # -- Signatures + FTS (fast, always run unless "none") --
    timing: dict[str, float] = {}
    stage_started = time.perf_counter()
    try:
        rows = store.get_nodes_without_signature()
        signature_rows: list[tuple[str, int]] = []
        for row in rows:
            node_id, name, kind, params, ret = (
                row[0],
                row[1],
                row[2],
                row[3],
                row[4],
            )
            if kind in ("Function", "Test"):
                sig = f"def {name}({params or ''})"
                if ret:
                    sig += f" -> {ret}"
            elif kind == "Class":
                sig = f"class {name}"
            else:
                sig = name
            signature_rows.append((sig[:512], node_id))
        # Single transaction via executemany instead of one autocommitted
        # UPDATE per node (issue #721).
        store.update_node_signatures(signature_rows)
        build_result["signatures_updated"] = True
    except (sqlite3.OperationalError, TypeError, KeyError) as e:
        logger.warning("Signature computation failed: %s", e)
        _note_contention(build_result, e)
        warnings.append(f"Signature computation failed: {type(e).__name__}: {e}")
    timing["signatures_s"] = max(
        0.0,
        round(time.perf_counter() - stage_started, 6),
    )

    stage_started = time.perf_counter()
    try:
        from code_review_graph.search import rebuild_fts_index, update_fts_index

        if full_rebuild:
            build_result["fts_indexed"] = rebuild_fts_index(store)
            build_result["fts_rebuilt"] = True
        else:
            # An update knows which files it re-parsed, so the index only has
            # to rewrite those rows instead of being dropped and repopulated.
            mode: list[str] = []
            build_result["fts_indexed"] = update_fts_index(
                store,
                _fts_file_hint(repo_root, changed_files),
                _out_mode=mode,
            )
            build_result["fts_rebuilt"] = mode == ["rebuild"]
    except (sqlite3.OperationalError, ImportError) as e:
        logger.warning("FTS index rebuild failed: %s", e)
        _note_contention(build_result, e)
        warnings.append(f"FTS index rebuild failed: {type(e).__name__}: {e}")
    timing["fts_s"] = max(
        0.0,
        round(time.perf_counter() - stage_started, 6),
    )

    if postprocess == "minimal":
        _run_embedding_refresh(
            store,
            build_result,
            warnings,
            provider=embedding_provider,
            model=embedding_model,
        )
        build_result["postprocess_timing"] = timing
        return warnings

    # -- Expensive: flows + communities (only for "full") --
    # Incremental mode also triggers when pre-replacement capture preserved
    # entry-point QNs even if the relative changed_files list alone would
    # miss absolute graph paths (#569).
    use_incremental = (
        not full_rebuild
        and not build_result.get("identity_rebuild")
        and (
            bool(changed_files)
            or bool(entry_point_qns)
            or communities_were_affected
        )
    )

    stage_started = time.perf_counter()
    try:
        if noop_incremental:
            count = 0
        elif use_incremental:
            from code_review_graph.flows import incremental_trace_flows

            count = incremental_trace_flows(
                store,
                changed_files or [],
                repo_root=repo_root,
                entry_point_qns=entry_point_qns,
            )
        else:
            from code_review_graph.flows import store_flows as _store_flows
            from code_review_graph.flows import trace_flows as _trace_flows

            flows = _trace_flows(store)
            count = _store_flows(store, flows)
        build_result["flows_detected"] = count
    except (sqlite3.OperationalError, ImportError) as e:
        logger.warning("Flow detection failed: %s", e)
        _note_contention(build_result, e)
        warnings.append(f"Flow detection failed: {type(e).__name__}: {e}")
    timing["flows_s"] = max(
        0.0,
        round(time.perf_counter() - stage_started, 6),
    )

    stage_started = time.perf_counter()
    try:
        if noop_incremental:
            count = store._conn.execute("SELECT COUNT(*) FROM communities").fetchone()[0]
        elif use_incremental:
            from code_review_graph.communities import (
                incremental_detect_communities,
            )

            count = incremental_detect_communities(
                store,
                changed_files or [],
                repo_root=repo_root,
                force=communities_were_affected,
            )
        else:
            from code_review_graph.communities import (
                detect_communities as _detect_communities,
            )
            from code_review_graph.communities import (
                store_communities as _store_communities,
            )

            comms = _detect_communities(store)
            count = _store_communities(store, comms)
        build_result["communities_detected"] = count
    except (sqlite3.OperationalError, ImportError) as e:
        logger.warning("Community detection failed: %s", e)
        _note_contention(build_result, e)
        warnings.append(f"Community detection failed: {type(e).__name__}: {e}")
    timing["communities_s"] = max(
        0.0,
        round(time.perf_counter() - stage_started, 6),
    )

    _run_embedding_refresh(
        store,
        build_result,
        warnings,
        provider=embedding_provider,
        model=embedding_model,
    )
    build_result["postprocess_timing"] = timing

    store.set_metadata(
        "last_postprocessed_at",
        time.strftime("%Y-%m-%dT%H:%M:%S"),
    )
    store.set_metadata("postprocess_level", postprocess)
    if hasattr(store, "shrink_memory"):
        store.shrink_memory()

    return warnings


def build_or_update_graph(
    full_rebuild: bool = False,
    repo_root: str | None = None,
    base: str | None = None,
    postprocess: str = "full",
    recurse_submodules: bool | None = None,
    embedding_provider: str | None = None,
    embedding_model: str | None = None,
    wait_for_lock: bool = False,
    recover_corrupt: bool = False,
    enrich: bool | None = None,
    follow_symlinks: bool | None = None,
) -> dict[str, Any]:
    """Build or incrementally update the code knowledge graph.

    Only one build runs per repository at a time. A second call that arrives
    while the first is still parsing reports ``status: contended`` and returns
    without touching the graph rather than repeating the same work: ``build``
    and ``update`` are fired from commit hooks, save hooks and the watcher,
    which can overlap by seconds, and each duplicate used to pay for a full
    parse plus its own process pool before failing on the SQLite write lock.
    Pass ``wait_for_lock=True`` (CLI: ``--wait``) to block instead of skipping.

    Args:
        full_rebuild: If True, re-parse every file. If False (default),
                      only re-parse files changed since ``base``.
        repo_root: Path to the repository root. Auto-detected if omitted.
        base: Git ref for the incremental diff. When None (default), the base
              is resolved automatically to the commit the graph was last built
              at, so a single update reconciles everything since the last sync
              rather than only the most recent commit. Pass an explicit ref to
              override. Ignored when full_rebuild is True.
        postprocess: Post-processing level after build:
            ``"full"`` (default) — signatures, FTS, flows, communities.
            ``"minimal"`` — signatures + FTS only (fast, keeps search working).
            ``"none"`` — skip all post-processing (raw parse only).
        recurse_submodules: If True, include files from git submodules
            via ``git ls-files --recurse-submodules``. When None
            (default), falls back to the CRG_RECURSE_SUBMODULES
            environment variable. Default: disabled.
        embedding_provider: Exact provider to use for an explicitly requested
            post-build refresh. Must be supplied together with
            ``embedding_model``; omitted by default so builds never transmit
            source-derived text or load an embedding model unexpectedly.
        embedding_model: Exact model for an explicitly requested post-build
            embedding refresh. Must be supplied with ``embedding_provider``.
        wait_for_lock: Block until an in-flight build for this repository
            finishes, instead of skipping. Default: False, because the
            skipping caller is usually a hook whose work the in-flight build
            already covers; a human running ``build``/``update`` by hand
            usually wants the wait.

        recover_corrupt: Discard an unusable graph before an explicit full rebuild.
            Used by the CLI build command; ignored for incremental updates.
        enrich: Also resolve Python method calls with Jedi (the
            ``enrichment`` extra; CLI: ``--enrich``). When None (default),
            falls back to ``CRG_ENABLE_ENRICHMENT``. Off by default because
            it costs about a second per Python file.
        follow_symlinks: If True, also index files in symlinked folders that
            point inside the repository (never outside it). When None
            (default), falls back to the CRG_FOLLOW_SYMLINKS environment
            variable. Default: disabled.

    Returns:
        Summary with files_parsed/updated, node/edge counts, and errors. A run
        that stood down because another build held the lock returns
        ``status: contended``, ``skipped: True`` and ``holder_pid``.
    """
    root = _resolve_root(repo_root)
    db_path = get_db_path(root, read_only=True)
    lock, contended = _lock_or_skip(db_path, wait_for_lock)
    if contended is not None:
        return contended
    store = None
    try:
        recovery_reason: str | None = None
        _prepare_db_path(root, db_path)
        store, root = _get_store(
            str(root), db_path=db_path, recover_corrupt=full_rebuild and recover_corrupt
        )
        if not full_rebuild and not store.has_nodes():
            full_rebuild = True

        # A previous run that died before post-processing left a current anchor
        # over a half-derived graph. Preserve the visible incomplete marker,
        # but only rebuild source files when storage itself was interrupted.
        interrupted = build_was_interrupted(store)
        if not graph_contents_are_complete(read_build_state(store)) and not full_rebuild:
            logger.warning(
                "Previous build stopped before all source files were stored; rebuilding"
            )
            full_rebuild = True

        # An automatic (base is None) incremental update resolves its diff base
        # to the last-synced commit. When no usable anchor exists, fall back to
        # a full rebuild rather than a wrong HEAD~1 diff that could report the
        # graph as up to date while it is actually stale.
        base_resolved: str | None = base
        if not full_rebuild and base is None:
            base_resolved = resolve_incremental_base(root, store)
            if base_resolved is None:
                full_rebuild = True

        if (
            not full_rebuild
            and _should_rebuild_partial_graph(root, store, recurse_submodules)
        ):
            full_rebuild = True
            recovery_reason = "partial_graph"

        previous_state = store.get_metadata(BUILD_STATE_KEY)
        store.set_metadata(BUILD_STATE_KEY, BUILD_IN_PROGRESS)

        if full_rebuild:
            result = full_build(
                root, store, recurse_submodules, enrich=enrich,
                follow_symlinks=follow_symlinks,
            )
            failed = [str(item.get("file", "?")) for item in result["errors"]]
            summary = (
                f"Full build complete: parsed {result['files_parsed']} files, "
                f"created {result['total_nodes']} nodes and "
                f"{result['total_edges']} edges."
            )
            if failed:
                summary += f" {len(failed)} file(s) failed to parse: {failed}."
            build_result = {
                **result,
                "status": "partial" if failed else "ok",
                "build_type": "full",
                "base_resolved": None,
                "summary": summary,
            }
            if recovery_reason is not None:
                build_result["recovery_reason"] = recovery_reason
        else:
            try:
                result = incremental_update(
                    root, store, base=base_resolved, enrich=enrich,
                    follow_symlinks=follow_symlinks,
                )
            except RuntimeError as exc:
                # Change discovery or root validation failed before anything was
                # stored; report it the way every other failure is reported.
                # Nothing was written, so the previous completeness verdict
                # still holds — do not leave the graph flagged as half built.
                if previous_state is not None:
                    store.set_metadata(BUILD_STATE_KEY, previous_state)
                return {
                    "status": "error",
                    "build_type": "incremental",
                    "base_resolved": base_resolved,
                    "files_updated": 0,
                    "errors": [],
                    "error": str(exc),
                    "summary": f"Incremental update failed: {exc}",
                    "postprocess_level": postprocess,
                }
            failed = [str(item.get("file", "?")) for item in result["errors"]]
            if result["files_updated"] == 0 and not failed and not (
                postprocess == "full" and store.get_metadata("csharp_flows_dirty") == "1"
            ):
                summary = (
                    "No changes detected. Graph is up to date."
                    if result.get("freshness_advanced")
                    else "No graph changes detected. Freshness metadata was not advanced."
                )
                if postprocess == "none":
                    # An explicit skip should not turn an existing state into
                    # a claim that derived data was checked. No source rows
                    # changed, so restore the state that was present before
                    # this no-op update began.
                    store.set_metadata(BUILD_STATE_KEY, previous_state or "")
                    noop_result = {
                        **result,
                        "status": "ok",
                        "build_type": "incremental",
                        "base_resolved": base_resolved,
                        "summary": summary,
                        "postprocess_level": postprocess,
                    }
                    # Match the other no-op levels: an explicit request should
                    # report that there is no embedding index to refresh.
                    if embedding_provider and embedding_model:
                        from code_review_graph.embeddings import has_embeddings

                        if not has_embeddings(store):
                            noop_warnings: list[str] = []
                            _report_refresh_skipped(noop_result, noop_warnings)
                            noop_result["warnings"] = noop_warnings
                    return noop_result

                # Older builds could leave FTS drift behind a complete marker.
                # Reconcile it even when Git has no source changes, while
                # keeping the no-op path away from the expensive flow and
                # community passes. A pending marker may also mean flows or
                # communities were interrupted; honor the requested level in
                # that case so a default update can finish the full repair.
                pending = previous_state == POSTPROCESS_PENDING
                postprocess_level = postprocess if pending else "minimal"
                build_result = {
                    **result,
                    "status": "ok",
                    "build_type": "incremental",
                    "base_resolved": base_resolved,
                    "summary": summary,
                }
                advance_to_postprocess_pending(store)
                warnings = _run_postprocess(
                    store,
                    build_result,
                    postprocess_level,
                    full_rebuild=False,
                    changed_files=None,
                    repo_root=str(root),
                    # The run that left the marker may have changed nodes. A
                    # complete graph has no resolver or embedding work to do,
                    # and hooks run this path after every edit.
                    embedding_provider=embedding_provider if pending else None,
                    embedding_model=embedding_model if pending else None,
                    skip_resolvers=not pending,
                )
                if warnings:
                    build_result["warnings"] = warnings
                if build_result.get("postprocess_failed"):
                    build_result["status"] = "partial"
                if not build_result.get("postprocess_contended"):
                    store.set_metadata(BUILD_STATE_KEY, BUILD_COMPLETE)
                build_result["repaired_interrupted_build"] = interrupted
                if not pending and embedding_provider and embedding_model:
                    from code_review_graph.embeddings import has_embeddings

                    if not has_embeddings(store):
                        embedding_warnings: list[str] = []
                        _report_refresh_skipped(build_result, embedding_warnings)
                        build_result.setdefault("warnings", []).extend(embedding_warnings)
                build_result["postprocess_level"] = postprocess_level
                return build_result
            summary = (
                f"Incremental update: {result['files_updated']} files re-parsed, "
                f"{result['total_nodes']} nodes and "
                f"{result['total_edges']} edges updated. "
                f"Changed: {result['changed_files']}. "
                f"Dependents also updated: {result['dependent_files']}."
            )
            if failed:
                summary += (
                    f" {len(failed)} file(s) failed to parse and keep their "
                    f"previous graph rows: {failed}."
                )
            build_result = {
                **result,
                "status": "partial" if failed else "ok",
                "build_type": "incremental",
                "base_resolved": base_resolved,
                "summary": summary,
            }

        # Every file that could be stored is stored, so what is still
        # outstanding is derived data alone. Recording that distinction here is
        # what lets an explicit ``postprocess`` tell a graph it can genuinely
        # repair from one whose files never all landed. ``full_build`` already
        # advances it before writing the anchor, so a kill in the gap between
        # the two is on the right side of the line; this covers the
        # incremental path and is a no-op when the state is already advanced.
        advance_to_postprocess_pending(store)

        # Pass changed_files + pre-replacement flow/community capture for
        # incremental postprocess (#569). A pending marker means derived tables
        # may be missing across the whole graph, so that case recomputes them
        # from all stored rows, while source parsing stays incremental.
        changed = None
        entry_qns = None
        communities_affected = False
        # Internal, and can run to thousands of names: not for the response.
        flow_entry_qns = build_result.pop("flow_entry_point_qns", None)
        if not full_rebuild and previous_state != POSTPROCESS_PENDING:
            changed = list(result.get("changed_files") or [])
            changed.extend(result.get("dependent_files") or [])
            entry_qns = list(flow_entry_qns or [])
            communities_affected = bool(
                result.get("communities_were_affected")
            )
        warnings = _run_postprocess(
            store,
            build_result,
            postprocess,
            full_rebuild=full_rebuild,
            changed_files=changed,
            repo_root=str(root),
            embedding_provider=embedding_provider,
            embedding_model=embedding_model,
            entry_point_qns=entry_qns,
            communities_were_affected=communities_affected,
        )
        if warnings:
            build_result["warnings"] = warnings
        # A genuine SQLite failure is not something the next run repairs, so it
        # is reported now rather than hidden behind an "ok" status.
        if build_result.get("postprocess_failed"):
            build_result["status"] = "partial"
        # Last thing written, after post-processing: only now is the graph
        # genuinely what its freshness metadata claims.  A stage that lost the
        # write lock keeps the marker set so the next run redoes it, rather
        # than leaving an empty FTS index behind a "complete" verdict.
        if not build_result.get("postprocess_contended") and postprocess != "none":
            store.set_metadata(BUILD_STATE_KEY, BUILD_COMPLETE)
        elif postprocess == "none" and failed:
            # A partial update can store some changed rows while another file
            # fails. Keep derived data visibly pending so a later update can
            # repair FTS/flows/communities for the rows that were stored.
            rows_changed = result.get("files_updated", 0) or result.get("files_parsed", 0)
            store.set_metadata(
                BUILD_STATE_KEY,
                POSTPROCESS_PENDING if rows_changed else (previous_state or ""),
            )
        build_result["repaired_interrupted_build"] = interrupted
        return build_result
    finally:
        try:
            if store is not None:
                store.close()
        finally:
            lock.release()


def _lock_or_skip(
    db_path: Path,
    wait_for_lock: bool,
    outcome: str = "skipped instead of repeating the work",
) -> tuple[WriteLock | None, dict[str, Any] | None]:
    """Take the graph's write lock, or build the response for standing down.

    Returns the held lock and ``None``, or ``None`` and the response to return.
    Every graph-writing entry point shares this so none can drift from the
    others. *outcome* says what standing down means for the caller.
    """
    lock = WriteLock(db_path)
    if lock.acquire(blocking=wait_for_lock):
        return lock, None
    return None, _write_skipped_response(db_path, lock.holder_pid(), outcome)


def _write_skipped_response(
    db_path: Path,
    holder_pid: int | None,
    outcome: str = "skipped instead of repeating the work",
) -> dict[str, Any]:
    """Describe a run that stood down because another writer owns the graph.

    ``contended`` rather than ``error``: nothing failed, and a caller switching
    on the existing statuses would otherwise have no way to tell a lost race
    from a broken database. The counts are present and zero so callers that
    unpack them keep working.

    A second build really does repeat the first, but ``forget`` and ``embed``
    are not covered by whatever else is running, so they pass their own
    *outcome* rather than tell the reader the work is in hand.
    """
    holder = f"PID {holder_pid}" if holder_pid is not None else "another process"
    return {
        "status": "contended",
        "skipped": True,
        "build_type": "none",
        "holder_pid": holder_pid,
        "lock_path": str(write_lock_path(db_path)),
        "files_parsed": 0,
        "files_updated": 0,
        "total_nodes": 0,
        "total_edges": 0,
        "errors": [],
        "summary": (
            f"Another code-review-graph write is already running for this "
            f"repository ({holder}); {outcome}. Pass wait_for_lock=True "
            f"(CLI: --wait) to block until it finishes."
        ),
    }


def run_postprocess(
    flows: bool = True,
    communities: bool = True,
    fts: bool = True,
    repo_root: str | None = None,
    embedding_provider: str | None = None,
    embedding_model: str | None = None,
    wait_for_lock: bool = False,
) -> dict[str, Any]:
    """Run post-processing steps on an existing graph.

    Useful for running expensive steps (flows, communities) separately
    from the build, or for re-running after the graph has been updated
    with ``postprocess="none"``.

    Takes the same per-repository write lock as ``build`` and ``update``: this
    rewrites derived data (flows, communities, FTS) for a graph another process
    may be half way through writing, which is the failure #1073 reports.

    Args:
        flows: Run flow detection. Default: True.
        communities: Run community detection. Default: True.
        fts: Rebuild FTS index. Default: True.
        repo_root: Repository root path. Auto-detected if omitted.
        embedding_provider: Exact provider for an explicit refresh. Must be
            supplied with ``embedding_model``. Default: disabled.
        embedding_model: Exact model for an explicit refresh. Must be supplied
            with ``embedding_provider``. Default: disabled.
        wait_for_lock: Block until an in-flight write for this repository
            finishes, instead of skipping. Default: False.

    Returns:
        Summary of what was computed, or ``status: contended`` when another
        writer held the lock.
    """
    root = _resolve_root(repo_root)
    db_path = get_db_path(root, read_only=True)
    lock, contended = _lock_or_skip(db_path, wait_for_lock)
    if contended is not None:
        return contended
    store = None
    result: dict[str, Any] = {"status": "ok"}
    warnings: list[str] = []

    try:
        _prepare_db_path(root, db_path)
        store, _root = _get_store(str(root), db_path=db_path)
        # Read before anything runs: the stages below rebuild derived data
        # from whatever nodes are stored, and none of them can put back a file
        # the interrupted build never parsed.
        state_before = read_build_state(store)
        graph_complete = graph_contents_are_complete(state_before)

        try:
            resolved = store.resolve_bare_call_targets()
            resolved += store.resolve_bare_tested_by_sources()
            result["bare_edges_resolved"] = resolved
            result["cpp_scoped_edges_resolved"] = (
                store.resolve_cpp_scoped_call_targets()
            )
            # Resolvers rewrite bare targets into qualified ones, so the
            # stored certainty column is only correct once they have run.
            store.refresh_target_resolution()
        except sqlite3.OperationalError as e:
            logger.warning("Call-target resolution failed: %s", e)
            _note_contention(result, e)
            warnings.append(
                f"Call-target resolution failed: {type(e).__name__}: {e}"
            )

        try:
            rows = store.get_nodes_without_signature()
            signature_rows: list[tuple[str, int]] = []
            for row in rows:
                node_id, name, kind, params, ret = (
                    row[0],
                    row[1],
                    row[2],
                    row[3],
                    row[4],
                )
                if kind in ("Function", "Test"):
                    sig = f"def {name}({params or ''})"
                    if ret:
                        sig += f" -> {ret}"
                elif kind == "Class":
                    sig = f"class {name}"
                else:
                    sig = name
                signature_rows.append((sig[:512], node_id))
            # Single transaction via executemany instead of one autocommitted
            # UPDATE per node (issue #721).
            store.update_node_signatures(signature_rows)
            result["signatures_updated"] = True
        except (sqlite3.OperationalError, TypeError, KeyError) as e:
            logger.warning("Signature computation failed: %s", e)
            _note_contention(result, e)
            warnings.append(f"Signature computation failed: {type(e).__name__}: {e}")

        if fts:
            try:
                from code_review_graph.search import rebuild_fts_index

                fts_count = rebuild_fts_index(store)
                result["fts_indexed"] = fts_count
            except (sqlite3.OperationalError, ImportError) as e:
                store.rollback()
                logger.warning("FTS index rebuild failed: %s", e)
                _note_contention(result, e)
                warnings.append(f"FTS index rebuild failed: {type(e).__name__}: {e}")

        if flows:
            try:
                from code_review_graph.flows import store_flows as _store_flows
                from code_review_graph.flows import trace_flows as _trace_flows

                traced = _trace_flows(store)
                count = _store_flows(store, traced)
                result["flows_detected"] = count
            except (sqlite3.OperationalError, ImportError) as e:
                store.rollback()
                logger.warning("Flow detection failed: %s", e)
                _note_contention(result, e)
                warnings.append(f"Flow detection failed: {type(e).__name__}: {e}")

        if communities:
            try:
                from code_review_graph.communities import (
                    detect_communities as _detect_communities,
                )
                from code_review_graph.communities import (
                    store_communities as _store_communities,
                )

                comms = _detect_communities(store)
                count = _store_communities(store, comms)
                result["communities_detected"] = count
            except (sqlite3.OperationalError, ImportError) as e:
                store.rollback()
                logger.warning("Community detection failed: %s", e)
                _note_contention(result, e)
                warnings.append(f"Community detection failed: {type(e).__name__}: {e}")

        _run_embedding_refresh(
            store,
            result,
            warnings,
            provider=embedding_provider,
            model=embedding_model,
        )

        store.set_metadata(
            "last_postprocessed_at",
            time.strftime("%Y-%m-%dT%H:%M:%S"),
        )
        # The marker clears when, and only when, post-processing finished over
        # a graph that holds every file.  Two conditions, both explicit:
        #
        # * The build that stored the graph got as far as storing all of it.
        #   An explicit postprocess is the hand repair for a build that died
        #   after that point, and must be able to finish it. Refusing on any
        #   warning meant it could not repair the very failures people reach
        #   for it to repair.  But it cannot conjure back files a dead build
        #   never parsed, so over an ``in-progress`` graph it is not a repair
        #   at all: the derived data it writes is complete for a graph that is
        #   missing files, and calling that healthy is the same lie from the
        #   other side.
        # * No stage lost the SQLite write lock.  Contention is transient and
        #   the lost stage has to be redone, so the marker stays set for it.
        if not graph_complete:
            warning = (
                "The last build stopped before every file was stored, so the "
                "graph is still incomplete. Post-processing rebuilt what it "
                "could from the stored nodes; run 'code-review-graph build' "
                "to finish the graph itself."
            )
            logger.warning(warning)
            warnings.append(warning)
            result["build_incomplete"] = True
            result["status"] = "partial"
            result["summary"] = (
                "Post-processing ran, but the graph is missing files from an "
                "unfinished build. Run a full build to repair it."
            )
        else:
            if not result.get("postprocess_contended"):
                store.set_metadata(BUILD_STATE_KEY, BUILD_COMPLETE)
            result["summary"] = "Post-processing complete."
        if warnings:
            result["warnings"] = warnings
        return result
    finally:
        try:
            if store is not None:
                store.close()
        finally:
            lock.release()
